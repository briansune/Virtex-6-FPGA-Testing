/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "I:/Xilinx_V6_xc6vlx365t/v6_golden_top_ddr_pwr_400mhz/v6_golden_top_ddr_pwr/ddr_pwr_ip/ddr_pwr_ip/user_design/rtl/phy/phy_dq_iob.v";
static int ng1[] = {20302, 0};
static int ng2[] = {5195334, 0};
static unsigned int ng3[] = {0U, 0U};
static unsigned int ng4[] = {1U, 0U};
static unsigned int ng5[] = {2U, 0U};
static unsigned int ng6[] = {3U, 0U};
static unsigned int ng7[] = {4U, 0U};
static unsigned int ng8[] = {5U, 0U};
static unsigned int ng9[] = {6U, 0U};
static unsigned int ng10[] = {7U, 0U};



static void Always_239_0(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;

LAB0:    t1 = (t0 + 15568U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(239, ng0);
    t2 = (t0 + 22336);
    *((int *)t2) = 1;
    t3 = (t0 + 15600);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(239, ng0);

LAB5:    xsi_set_current_line(240, ng0);
    t4 = (t0 + 4008U);
    t5 = *((char **)t4);
    t4 = (t0 + 13528);
    xsi_vlogvar_wait_assign_value(t4, t5, 0, 0, 1, 1000LL);
    xsi_set_current_line(241, ng0);
    t2 = (t0 + 4168U);
    t3 = *((char **)t2);
    t2 = (t0 + 12248);
    xsi_vlogvar_wait_assign_value(t2, t3, 0, 0, 1, 1000LL);
    xsi_set_current_line(242, ng0);
    t2 = (t0 + 4328U);
    t3 = *((char **)t2);
    t2 = (t0 + 14168);
    xsi_vlogvar_wait_assign_value(t2, t3, 0, 0, 1, 1000LL);
    xsi_set_current_line(243, ng0);
    t2 = (t0 + 4488U);
    t3 = *((char **)t2);
    t2 = (t0 + 12888);
    xsi_vlogvar_wait_assign_value(t2, t3, 0, 0, 1, 1000LL);
    xsi_set_current_line(244, ng0);
    t2 = (t0 + 13528);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 13688);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 1, 1000LL);
    xsi_set_current_line(245, ng0);
    t2 = (t0 + 12248);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 12408);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 1, 1000LL);
    xsi_set_current_line(246, ng0);
    t2 = (t0 + 14168);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 14328);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 1, 1000LL);
    xsi_set_current_line(247, ng0);
    t2 = (t0 + 12888);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 13048);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 1, 1000LL);
    xsi_set_current_line(248, ng0);
    t2 = (t0 + 13688);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 13848);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 1, 1000LL);
    xsi_set_current_line(249, ng0);
    t2 = (t0 + 12408);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 12568);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 1, 1000LL);
    xsi_set_current_line(250, ng0);
    t2 = (t0 + 14328);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 14488);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 1, 1000LL);
    xsi_set_current_line(251, ng0);
    t2 = (t0 + 13048);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 13208);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 1, 1000LL);
    xsi_set_current_line(252, ng0);
    t2 = (t0 + 13848);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 14008);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 1, 1000LL);
    xsi_set_current_line(253, ng0);
    t2 = (t0 + 12568);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 12728);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 1, 1000LL);
    xsi_set_current_line(254, ng0);
    t2 = (t0 + 14488);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 14648);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 1, 1000LL);
    xsi_set_current_line(255, ng0);
    t2 = (t0 + 13208);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 13368);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 1, 1000LL);
    goto LAB2;

}

static void Always_262_1(char *t0)
{
    char t6[8];
    char t32[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t7;
    char *t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    char *t21;
    char *t22;
    unsigned int t23;
    unsigned int t24;
    unsigned int t25;
    unsigned int t26;
    unsigned int t27;
    char *t28;
    char *t29;
    char *t30;
    char *t31;
    int t33;

LAB0:    t1 = (t0 + 15816U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(262, ng0);
    t2 = (t0 + 22352);
    *((int *)t2) = 1;
    t3 = (t0 + 15848);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(262, ng0);

LAB5:    xsi_set_current_line(263, ng0);
    t4 = ((char*)((ng1)));
    t5 = ((char*)((ng2)));
    memset(t6, 0, 8);
    t7 = (t4 + 4);
    t8 = (t5 + 4);
    t9 = *((unsigned int *)t4);
    t10 = *((unsigned int *)t5);
    t11 = (t9 ^ t10);
    t12 = *((unsigned int *)t7);
    t13 = *((unsigned int *)t8);
    t14 = (t12 ^ t13);
    t15 = (t11 | t14);
    t16 = *((unsigned int *)t7);
    t17 = *((unsigned int *)t8);
    t18 = (t16 | t17);
    t19 = (~(t18));
    t20 = (t15 & t19);
    if (t20 != 0)
        goto LAB9;

LAB6:    if (t18 != 0)
        goto LAB8;

LAB7:    *((unsigned int *)t6) = 1;

LAB9:    t22 = (t6 + 4);
    t23 = *((unsigned int *)t22);
    t24 = (~(t23));
    t25 = *((unsigned int *)t6);
    t26 = (t25 & t24);
    t27 = (t26 != 0);
    if (t27 > 0)
        goto LAB10;

LAB11:    xsi_set_current_line(268, ng0);

LAB14:    xsi_set_current_line(274, ng0);
    t2 = (t0 + 3528U);
    t3 = *((char **)t2);
    t2 = (t0 + 3688U);
    t4 = *((char **)t2);
    memset(t32, 0, 8);
    t2 = (t32 + 4);
    t5 = (t4 + 4);
    t9 = *((unsigned int *)t4);
    t10 = (t9 >> 0);
    *((unsigned int *)t32) = t10;
    t11 = *((unsigned int *)t5);
    t12 = (t11 >> 0);
    *((unsigned int *)t2) = t12;
    t13 = *((unsigned int *)t32);
    *((unsigned int *)t32) = (t13 & 3U);
    t14 = *((unsigned int *)t2);
    *((unsigned int *)t2) = (t14 & 3U);
    xsi_vlogtype_concat(t6, 3, 3, 2U, t32, 2, t3, 1);

LAB15:    t7 = ((char*)((ng3)));
    t33 = xsi_vlog_unsigned_case_compare(t6, 3, t7, 3);
    if (t33 == 1)
        goto LAB16;

LAB17:    t2 = ((char*)((ng4)));
    t33 = xsi_vlog_unsigned_case_compare(t6, 3, t2, 3);
    if (t33 == 1)
        goto LAB18;

LAB19:    t2 = ((char*)((ng5)));
    t33 = xsi_vlog_unsigned_case_compare(t6, 3, t2, 3);
    if (t33 == 1)
        goto LAB20;

LAB21:    t2 = ((char*)((ng6)));
    t33 = xsi_vlog_unsigned_case_compare(t6, 3, t2, 3);
    if (t33 == 1)
        goto LAB22;

LAB23:    t2 = ((char*)((ng7)));
    t33 = xsi_vlog_unsigned_case_compare(t6, 3, t2, 3);
    if (t33 == 1)
        goto LAB24;

LAB25:    t2 = ((char*)((ng8)));
    t33 = xsi_vlog_unsigned_case_compare(t6, 3, t2, 3);
    if (t33 == 1)
        goto LAB26;

LAB27:    t2 = ((char*)((ng9)));
    t33 = xsi_vlog_unsigned_case_compare(t6, 3, t2, 3);
    if (t33 == 1)
        goto LAB28;

LAB29:    t2 = ((char*)((ng10)));
    t33 = xsi_vlog_unsigned_case_compare(t6, 3, t2, 3);
    if (t33 == 1)
        goto LAB30;

LAB31:
LAB33:
LAB32:    xsi_set_current_line(335, ng0);

LAB43:    xsi_set_current_line(336, ng0);
    t2 = (t0 + 12248);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 10968);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 1, 1000LL);
    xsi_set_current_line(337, ng0);
    t2 = (t0 + 14168);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 11128);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 1, 1000LL);
    xsi_set_current_line(338, ng0);
    t2 = (t0 + 12888);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 11288);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 1, 1000LL);
    xsi_set_current_line(339, ng0);
    t2 = (t0 + 4008U);
    t3 = *((char **)t2);
    t2 = (t0 + 11448);
    xsi_vlogvar_wait_assign_value(t2, t3, 0, 0, 1, 1000LL);

LAB34:
LAB12:    goto LAB2;

LAB8:    t21 = (t6 + 4);
    *((unsigned int *)t6) = 1;
    *((unsigned int *)t21) = 1;
    goto LAB9;

LAB10:    xsi_set_current_line(263, ng0);

LAB13:    xsi_set_current_line(264, ng0);
    t28 = (t0 + 13528);
    t29 = (t28 + 56U);
    t30 = *((char **)t29);
    t31 = (t0 + 10968);
    xsi_vlogvar_wait_assign_value(t31, t30, 0, 0, 1, 1000LL);
    xsi_set_current_line(265, ng0);
    t2 = (t0 + 12248);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 11128);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 1, 1000LL);
    xsi_set_current_line(266, ng0);
    t2 = (t0 + 14168);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 11288);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 1, 1000LL);
    xsi_set_current_line(267, ng0);
    t2 = (t0 + 12888);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 11448);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 1, 1000LL);
    goto LAB12;

LAB16:    xsi_set_current_line(276, ng0);

LAB35:    xsi_set_current_line(277, ng0);
    t8 = (t0 + 12248);
    t21 = (t8 + 56U);
    t22 = *((char **)t21);
    t28 = (t0 + 10968);
    xsi_vlogvar_wait_assign_value(t28, t22, 0, 0, 1, 1000LL);
    xsi_set_current_line(278, ng0);
    t2 = (t0 + 14168);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 11128);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 1, 1000LL);
    xsi_set_current_line(279, ng0);
    t2 = (t0 + 12888);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 11288);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 1, 1000LL);
    xsi_set_current_line(280, ng0);
    t2 = (t0 + 4008U);
    t3 = *((char **)t2);
    t2 = (t0 + 11448);
    xsi_vlogvar_wait_assign_value(t2, t3, 0, 0, 1, 1000LL);
    goto LAB34;

LAB18:    xsi_set_current_line(283, ng0);

LAB36:    xsi_set_current_line(284, ng0);
    t3 = (t0 + 13528);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t7 = (t0 + 10968);
    xsi_vlogvar_wait_assign_value(t7, t5, 0, 0, 1, 1000LL);
    xsi_set_current_line(285, ng0);
    t2 = (t0 + 12248);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 11128);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 1, 1000LL);
    xsi_set_current_line(286, ng0);
    t2 = (t0 + 14168);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 11288);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 1, 1000LL);
    xsi_set_current_line(287, ng0);
    t2 = (t0 + 12888);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 11448);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 1, 1000LL);
    goto LAB34;

LAB20:    xsi_set_current_line(290, ng0);

LAB37:    xsi_set_current_line(291, ng0);
    t3 = (t0 + 13048);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t7 = (t0 + 10968);
    xsi_vlogvar_wait_assign_value(t7, t5, 0, 0, 1, 1000LL);
    xsi_set_current_line(292, ng0);
    t2 = (t0 + 13528);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 11128);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 1, 1000LL);
    xsi_set_current_line(293, ng0);
    t2 = (t0 + 12248);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 11288);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 1, 1000LL);
    xsi_set_current_line(294, ng0);
    t2 = (t0 + 14168);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 11448);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 1, 1000LL);
    goto LAB34;

LAB22:    xsi_set_current_line(298, ng0);

LAB38:    xsi_set_current_line(299, ng0);
    t3 = (t0 + 14328);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t7 = (t0 + 10968);
    xsi_vlogvar_wait_assign_value(t7, t5, 0, 0, 1, 1000LL);
    xsi_set_current_line(300, ng0);
    t2 = (t0 + 13048);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 11128);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 1, 1000LL);
    xsi_set_current_line(301, ng0);
    t2 = (t0 + 13528);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 11288);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 1, 1000LL);
    xsi_set_current_line(302, ng0);
    t2 = (t0 + 12248);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 11448);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 1, 1000LL);
    goto LAB34;

LAB24:    xsi_set_current_line(305, ng0);

LAB39:    xsi_set_current_line(306, ng0);
    t3 = (t0 + 12408);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t7 = (t0 + 10968);
    xsi_vlogvar_wait_assign_value(t7, t5, 0, 0, 1, 1000LL);
    xsi_set_current_line(307, ng0);
    t2 = (t0 + 14328);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 11128);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 1, 1000LL);
    xsi_set_current_line(308, ng0);
    t2 = (t0 + 13048);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 11288);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 1, 1000LL);
    xsi_set_current_line(309, ng0);
    t2 = (t0 + 13528);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 11448);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 1, 1000LL);
    goto LAB34;

LAB26:    xsi_set_current_line(313, ng0);

LAB40:    xsi_set_current_line(314, ng0);
    t3 = (t0 + 13688);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t7 = (t0 + 10968);
    xsi_vlogvar_wait_assign_value(t7, t5, 0, 0, 1, 1000LL);
    xsi_set_current_line(315, ng0);
    t2 = (t0 + 12408);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 11128);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 1, 1000LL);
    xsi_set_current_line(316, ng0);
    t2 = (t0 + 14328);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 11288);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 1, 1000LL);
    xsi_set_current_line(317, ng0);
    t2 = (t0 + 13048);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 11448);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 1, 1000LL);
    goto LAB34;

LAB28:    xsi_set_current_line(320, ng0);

LAB41:    xsi_set_current_line(321, ng0);
    t3 = (t0 + 13208);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t7 = (t0 + 10968);
    xsi_vlogvar_wait_assign_value(t7, t5, 0, 0, 1, 1000LL);
    xsi_set_current_line(322, ng0);
    t2 = (t0 + 13688);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 11128);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 1, 1000LL);
    xsi_set_current_line(323, ng0);
    t2 = (t0 + 12408);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 11288);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 1, 1000LL);
    xsi_set_current_line(324, ng0);
    t2 = (t0 + 14328);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 11448);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 1, 1000LL);
    goto LAB34;

LAB30:    xsi_set_current_line(328, ng0);

LAB42:    xsi_set_current_line(329, ng0);
    t3 = (t0 + 14488);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t7 = (t0 + 10968);
    xsi_vlogvar_wait_assign_value(t7, t5, 0, 0, 1, 1000LL);
    xsi_set_current_line(330, ng0);
    t2 = (t0 + 13208);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 11128);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 1, 1000LL);
    xsi_set_current_line(331, ng0);
    t2 = (t0 + 13688);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 11288);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 1, 1000LL);
    xsi_set_current_line(332, ng0);
    t2 = (t0 + 12408);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 11448);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 1, 1000LL);
    goto LAB34;

}

static void Cont_531_2(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    unsigned int t8;
    unsigned int t9;
    char *t10;
    unsigned int t11;
    unsigned int t12;
    char *t13;
    unsigned int t14;
    unsigned int t15;
    char *t16;

LAB0:    t1 = (t0 + 16064U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(531, ng0);
    t2 = (t0 + 2888U);
    t3 = *((char **)t2);
    t2 = (t0 + 22576);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    memset(t7, 0, 8);
    t8 = 1U;
    t9 = t8;
    t10 = (t3 + 4);
    t11 = *((unsigned int *)t3);
    t8 = (t8 & t11);
    t12 = *((unsigned int *)t10);
    t9 = (t9 & t12);
    t13 = (t7 + 4);
    t14 = *((unsigned int *)t7);
    *((unsigned int *)t7) = (t14 | t8);
    t15 = *((unsigned int *)t13);
    *((unsigned int *)t13) = (t15 | t9);
    xsi_driver_vfirst_trans(t2, 0, 0);
    t16 = (t0 + 22368);
    *((int *)t16) = 1;

LAB1:    return;
}

static void Cont_532_3(char *t0)
{
    char t3[8];
    char *t1;
    char *t2;
    char *t4;
    unsigned int t5;
    unsigned int t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    char *t10;
    char *t11;
    char *t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    char *t21;
    char *t22;
    char *t23;
    char *t24;
    char *t25;
    unsigned int t26;
    unsigned int t27;
    char *t28;
    unsigned int t29;
    unsigned int t30;
    char *t31;
    unsigned int t32;
    unsigned int t33;
    char *t34;

LAB0:    t1 = (t0 + 16312U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(532, ng0);
    t2 = (t0 + 2888U);
    t4 = *((char **)t2);
    memset(t3, 0, 8);
    t2 = (t4 + 4);
    t5 = *((unsigned int *)t2);
    t6 = (~(t5));
    t7 = *((unsigned int *)t4);
    t8 = (t7 & t6);
    t9 = (t8 & 1U);
    if (t9 != 0)
        goto LAB7;

LAB5:    if (*((unsigned int *)t2) == 0)
        goto LAB4;

LAB6:    t10 = (t3 + 4);
    *((unsigned int *)t3) = 1;
    *((unsigned int *)t10) = 1;

LAB7:    t11 = (t3 + 4);
    t12 = (t4 + 4);
    t13 = *((unsigned int *)t4);
    t14 = (~(t13));
    *((unsigned int *)t3) = t14;
    *((unsigned int *)t11) = 0;
    if (*((unsigned int *)t12) != 0)
        goto LAB9;

LAB8:    t19 = *((unsigned int *)t3);
    *((unsigned int *)t3) = (t19 & 1U);
    t20 = *((unsigned int *)t11);
    *((unsigned int *)t11) = (t20 & 1U);
    t21 = (t0 + 22640);
    t22 = (t21 + 56U);
    t23 = *((char **)t22);
    t24 = (t23 + 56U);
    t25 = *((char **)t24);
    memset(t25, 0, 8);
    t26 = 1U;
    t27 = t26;
    t28 = (t3 + 4);
    t29 = *((unsigned int *)t3);
    t26 = (t26 & t29);
    t30 = *((unsigned int *)t28);
    t27 = (t27 & t30);
    t31 = (t25 + 4);
    t32 = *((unsigned int *)t25);
    *((unsigned int *)t25) = (t32 | t26);
    t33 = *((unsigned int *)t31);
    *((unsigned int *)t31) = (t33 | t27);
    xsi_driver_vfirst_trans(t21, 0, 0);
    t34 = (t0 + 22384);
    *((int *)t34) = 1;

LAB1:    return;
LAB4:    *((unsigned int *)t3) = 1;
    goto LAB7;

LAB9:    t15 = *((unsigned int *)t3);
    t16 = *((unsigned int *)t12);
    *((unsigned int *)t3) = (t15 | t16);
    t17 = *((unsigned int *)t11);
    t18 = *((unsigned int *)t12);
    *((unsigned int *)t11) = (t17 | t18);
    goto LAB8;

}

static void Always_592_4(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;

LAB0:    t1 = (t0 + 16560U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(592, ng0);
    t2 = (t0 + 22400);
    *((int *)t2) = 1;
    t3 = (t0 + 16592);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(593, ng0);
    t4 = (t0 + 7208U);
    t5 = *((char **)t4);
    t4 = (t0 + 10648);
    xsi_vlogvar_wait_assign_value(t4, t5, 0, 0, 6, 1000LL);
    goto LAB2;

}

static void Always_594_5(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;

LAB0:    t1 = (t0 + 16808U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(594, ng0);
    t2 = (t0 + 22416);
    *((int *)t2) = 1;
    t3 = (t0 + 16840);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(595, ng0);
    t4 = (t0 + 10648);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t7 = (t0 + 10808);
    xsi_vlogvar_wait_assign_value(t7, t6, 0, 0, 6, 1000LL);
    goto LAB2;

}

static void Cont_597_6(char *t0)
{
    char t3[8];
    char t4[8];
    char *t1;
    char *t2;
    char *t5;
    unsigned int t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    char *t11;
    char *t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    char *t16;
    char *t17;
    char *t18;
    unsigned int t19;
    unsigned int t20;
    unsigned int t21;
    unsigned int t22;
    char *t23;
    char *t24;
    char *t25;
    char *t26;
    char *t27;
    char *t28;
    unsigned int t29;
    unsigned int t30;
    char *t31;
    unsigned int t32;
    unsigned int t33;
    char *t34;
    unsigned int t35;
    unsigned int t36;
    char *t37;

LAB0:    t1 = (t0 + 17056U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(597, ng0);
    t2 = (t0 + 4968U);
    t5 = *((char **)t2);
    memset(t4, 0, 8);
    t2 = (t5 + 4);
    t6 = *((unsigned int *)t2);
    t7 = (~(t6));
    t8 = *((unsigned int *)t5);
    t9 = (t8 & t7);
    t10 = (t9 & 1U);
    if (t10 != 0)
        goto LAB4;

LAB5:    if (*((unsigned int *)t2) != 0)
        goto LAB6;

LAB7:    t12 = (t4 + 4);
    t13 = *((unsigned int *)t4);
    t14 = *((unsigned int *)t12);
    t15 = (t13 || t14);
    if (t15 > 0)
        goto LAB8;

LAB9:    t19 = *((unsigned int *)t4);
    t20 = (~(t19));
    t21 = *((unsigned int *)t12);
    t22 = (t20 || t21);
    if (t22 > 0)
        goto LAB10;

LAB11:    if (*((unsigned int *)t12) > 0)
        goto LAB12;

LAB13:    if (*((unsigned int *)t4) > 0)
        goto LAB14;

LAB15:    memcpy(t3, t24, 8);

LAB16:    t23 = (t0 + 22704);
    t25 = (t23 + 56U);
    t26 = *((char **)t25);
    t27 = (t26 + 56U);
    t28 = *((char **)t27);
    memset(t28, 0, 8);
    t29 = 63U;
    t30 = t29;
    t31 = (t3 + 4);
    t32 = *((unsigned int *)t3);
    t29 = (t29 & t32);
    t33 = *((unsigned int *)t31);
    t30 = (t30 & t33);
    t34 = (t28 + 4);
    t35 = *((unsigned int *)t28);
    *((unsigned int *)t28) = (t35 | t29);
    t36 = *((unsigned int *)t34);
    *((unsigned int *)t34) = (t36 | t30);
    xsi_driver_vfirst_trans(t23, 0, 5);
    t37 = (t0 + 22432);
    *((int *)t37) = 1;

LAB1:    return;
LAB4:    *((unsigned int *)t4) = 1;
    goto LAB7;

LAB6:    t11 = (t4 + 4);
    *((unsigned int *)t4) = 1;
    *((unsigned int *)t11) = 1;
    goto LAB7;

LAB8:    t16 = (t0 + 10808);
    t17 = (t16 + 56U);
    t18 = *((char **)t17);
    goto LAB9;

LAB10:    t23 = (t0 + 7208U);
    t24 = *((char **)t23);
    goto LAB11;

LAB12:    xsi_vlog_unsigned_bit_combine(t3, 6, t18, 6, t24, 6);
    goto LAB16;

LAB14:    memcpy(t3, t18, 8);
    goto LAB16;

}

static void Cont_616_7(char *t0)
{
    char t4[8];
    char *t1;
    char *t2;
    char *t3;
    char *t5;
    unsigned int t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    unsigned int t17;
    unsigned int t18;
    char *t19;
    unsigned int t20;
    unsigned int t21;
    char *t22;
    unsigned int t23;
    unsigned int t24;
    char *t25;

LAB0:    t1 = (t0 + 17304U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(616, ng0);
    t2 = (t0 + 7688U);
    t3 = *((char **)t2);
    memset(t4, 0, 8);
    t2 = (t4 + 4);
    t5 = (t3 + 4);
    t6 = *((unsigned int *)t3);
    t7 = (t6 >> 3);
    t8 = (t7 & 1);
    *((unsigned int *)t4) = t8;
    t9 = *((unsigned int *)t5);
    t10 = (t9 >> 3);
    t11 = (t10 & 1);
    *((unsigned int *)t2) = t11;
    t12 = (t0 + 22768);
    t13 = (t12 + 56U);
    t14 = *((char **)t13);
    t15 = (t14 + 56U);
    t16 = *((char **)t15);
    memset(t16, 0, 8);
    t17 = 1U;
    t18 = t17;
    t19 = (t4 + 4);
    t20 = *((unsigned int *)t4);
    t17 = (t17 & t20);
    t21 = *((unsigned int *)t19);
    t18 = (t18 & t21);
    t22 = (t16 + 4);
    t23 = *((unsigned int *)t16);
    *((unsigned int *)t16) = (t23 | t17);
    t24 = *((unsigned int *)t22);
    *((unsigned int *)t22) = (t24 | t18);
    xsi_driver_vfirst_trans(t12, 0, 0);
    t25 = (t0 + 22448);
    *((int *)t25) = 1;

LAB1:    return;
}

static void Cont_617_8(char *t0)
{
    char t4[8];
    char *t1;
    char *t2;
    char *t3;
    char *t5;
    unsigned int t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    unsigned int t17;
    unsigned int t18;
    char *t19;
    unsigned int t20;
    unsigned int t21;
    char *t22;
    unsigned int t23;
    unsigned int t24;
    char *t25;

LAB0:    t1 = (t0 + 17552U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(617, ng0);
    t2 = (t0 + 7688U);
    t3 = *((char **)t2);
    memset(t4, 0, 8);
    t2 = (t4 + 4);
    t5 = (t3 + 4);
    t6 = *((unsigned int *)t3);
    t7 = (t6 >> 2);
    t8 = (t7 & 1);
    *((unsigned int *)t4) = t8;
    t9 = *((unsigned int *)t5);
    t10 = (t9 >> 2);
    t11 = (t10 & 1);
    *((unsigned int *)t2) = t11;
    t12 = (t0 + 22832);
    t13 = (t12 + 56U);
    t14 = *((char **)t13);
    t15 = (t14 + 56U);
    t16 = *((char **)t15);
    memset(t16, 0, 8);
    t17 = 1U;
    t18 = t17;
    t19 = (t4 + 4);
    t20 = *((unsigned int *)t4);
    t17 = (t17 & t20);
    t21 = *((unsigned int *)t19);
    t18 = (t18 & t21);
    t22 = (t16 + 4);
    t23 = *((unsigned int *)t16);
    *((unsigned int *)t16) = (t23 | t17);
    t24 = *((unsigned int *)t22);
    *((unsigned int *)t22) = (t24 | t18);
    xsi_driver_vfirst_trans(t12, 0, 0);
    t25 = (t0 + 22464);
    *((int *)t25) = 1;

LAB1:    return;
}

static void Cont_618_9(char *t0)
{
    char t4[8];
    char *t1;
    char *t2;
    char *t3;
    char *t5;
    unsigned int t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    unsigned int t17;
    unsigned int t18;
    char *t19;
    unsigned int t20;
    unsigned int t21;
    char *t22;
    unsigned int t23;
    unsigned int t24;
    char *t25;

LAB0:    t1 = (t0 + 17800U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(618, ng0);
    t2 = (t0 + 7688U);
    t3 = *((char **)t2);
    memset(t4, 0, 8);
    t2 = (t4 + 4);
    t5 = (t3 + 4);
    t6 = *((unsigned int *)t3);
    t7 = (t6 >> 1);
    t8 = (t7 & 1);
    *((unsigned int *)t4) = t8;
    t9 = *((unsigned int *)t5);
    t10 = (t9 >> 1);
    t11 = (t10 & 1);
    *((unsigned int *)t2) = t11;
    t12 = (t0 + 22896);
    t13 = (t12 + 56U);
    t14 = *((char **)t13);
    t15 = (t14 + 56U);
    t16 = *((char **)t15);
    memset(t16, 0, 8);
    t17 = 1U;
    t18 = t17;
    t19 = (t4 + 4);
    t20 = *((unsigned int *)t4);
    t17 = (t17 & t20);
    t21 = *((unsigned int *)t19);
    t18 = (t18 & t21);
    t22 = (t16 + 4);
    t23 = *((unsigned int *)t16);
    *((unsigned int *)t16) = (t23 | t17);
    t24 = *((unsigned int *)t22);
    *((unsigned int *)t22) = (t24 | t18);
    xsi_driver_vfirst_trans(t12, 0, 0);
    t25 = (t0 + 22480);
    *((int *)t25) = 1;

LAB1:    return;
}

static void Cont_619_10(char *t0)
{
    char t4[8];
    char *t1;
    char *t2;
    char *t3;
    char *t5;
    unsigned int t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    unsigned int t17;
    unsigned int t18;
    char *t19;
    unsigned int t20;
    unsigned int t21;
    char *t22;
    unsigned int t23;
    unsigned int t24;
    char *t25;

LAB0:    t1 = (t0 + 18048U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(619, ng0);
    t2 = (t0 + 7688U);
    t3 = *((char **)t2);
    memset(t4, 0, 8);
    t2 = (t4 + 4);
    t5 = (t3 + 4);
    t6 = *((unsigned int *)t3);
    t7 = (t6 >> 0);
    t8 = (t7 & 1);
    *((unsigned int *)t4) = t8;
    t9 = *((unsigned int *)t5);
    t10 = (t9 >> 0);
    t11 = (t10 & 1);
    *((unsigned int *)t2) = t11;
    t12 = (t0 + 22960);
    t13 = (t12 + 56U);
    t14 = *((char **)t13);
    t15 = (t14 + 56U);
    t16 = *((char **)t15);
    memset(t16, 0, 8);
    t17 = 1U;
    t18 = t17;
    t19 = (t4 + 4);
    t20 = *((unsigned int *)t4);
    t17 = (t17 & t20);
    t21 = *((unsigned int *)t19);
    t18 = (t18 & t21);
    t22 = (t16 + 4);
    t23 = *((unsigned int *)t16);
    *((unsigned int *)t16) = (t23 | t17);
    t24 = *((unsigned int *)t22);
    *((unsigned int *)t22) = (t24 | t18);
    xsi_driver_vfirst_trans(t12, 0, 0);
    t25 = (t0 + 22496);
    *((int *)t25) = 1;

LAB1:    return;
}

static void implSig1_execute(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    unsigned int t8;
    unsigned int t9;
    char *t10;
    unsigned int t11;
    unsigned int t12;
    char *t13;
    unsigned int t14;
    unsigned int t15;

LAB0:    t1 = (t0 + 18296U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    t2 = ((char*)((ng3)));
    t3 = (t0 + 23024);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    memset(t7, 0, 8);
    t8 = 1U;
    t9 = t8;
    t10 = (t2 + 4);
    t11 = *((unsigned int *)t2);
    t8 = (t8 & t11);
    t12 = *((unsigned int *)t10);
    t9 = (t9 & t12);
    t13 = (t7 + 4);
    t14 = *((unsigned int *)t7);
    *((unsigned int *)t7) = (t14 | t8);
    t15 = *((unsigned int *)t13);
    *((unsigned int *)t13) = (t15 | t9);
    xsi_driver_vfirst_trans(t3, 0, 0);

LAB1:    return;
}

static void implSig2_execute(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    unsigned int t8;
    unsigned int t9;
    char *t10;
    unsigned int t11;
    unsigned int t12;
    char *t13;
    unsigned int t14;
    unsigned int t15;

LAB0:    t1 = (t0 + 18544U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    t2 = ((char*)((ng3)));
    t3 = (t0 + 23088);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    memset(t7, 0, 8);
    t8 = 1U;
    t9 = t8;
    t10 = (t2 + 4);
    t11 = *((unsigned int *)t2);
    t8 = (t8 & t11);
    t12 = *((unsigned int *)t10);
    t9 = (t9 & t12);
    t13 = (t7 + 4);
    t14 = *((unsigned int *)t7);
    *((unsigned int *)t7) = (t14 | t8);
    t15 = *((unsigned int *)t13);
    *((unsigned int *)t13) = (t15 | t9);
    xsi_driver_vfirst_trans(t3, 0, 0);

LAB1:    return;
}

static void implSig3_execute(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    unsigned int t8;
    unsigned int t9;
    char *t10;
    unsigned int t11;
    unsigned int t12;
    char *t13;
    unsigned int t14;
    unsigned int t15;

LAB0:    t1 = (t0 + 18792U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    t2 = ((char*)((ng3)));
    t3 = (t0 + 23152);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    memset(t7, 0, 8);
    t8 = 1U;
    t9 = t8;
    t10 = (t2 + 4);
    t11 = *((unsigned int *)t2);
    t8 = (t8 & t11);
    t12 = *((unsigned int *)t10);
    t9 = (t9 & t12);
    t13 = (t7 + 4);
    t14 = *((unsigned int *)t7);
    *((unsigned int *)t7) = (t14 | t8);
    t15 = *((unsigned int *)t13);
    *((unsigned int *)t13) = (t15 | t9);
    xsi_driver_vfirst_trans(t3, 0, 0);

LAB1:    return;
}

static void implSig4_execute(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    unsigned int t8;
    unsigned int t9;
    char *t10;
    unsigned int t11;
    unsigned int t12;
    char *t13;
    unsigned int t14;
    unsigned int t15;

LAB0:    t1 = (t0 + 19040U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    t2 = ((char*)((ng4)));
    t3 = (t0 + 23216);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    memset(t7, 0, 8);
    t8 = 1U;
    t9 = t8;
    t10 = (t2 + 4);
    t11 = *((unsigned int *)t2);
    t8 = (t8 & t11);
    t12 = *((unsigned int *)t10);
    t9 = (t9 & t12);
    t13 = (t7 + 4);
    t14 = *((unsigned int *)t7);
    *((unsigned int *)t7) = (t14 | t8);
    t15 = *((unsigned int *)t13);
    *((unsigned int *)t13) = (t15 | t9);
    xsi_driver_vfirst_trans(t3, 0, 0);

LAB1:    return;
}

static void implSig5_execute(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    unsigned int t8;
    unsigned int t9;
    char *t10;
    unsigned int t11;
    unsigned int t12;
    char *t13;
    unsigned int t14;
    unsigned int t15;

LAB0:    t1 = (t0 + 19288U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    t2 = ((char*)((ng3)));
    t3 = (t0 + 23280);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    memset(t7, 0, 8);
    t8 = 1U;
    t9 = t8;
    t10 = (t2 + 4);
    t11 = *((unsigned int *)t2);
    t8 = (t8 & t11);
    t12 = *((unsigned int *)t10);
    t9 = (t9 & t12);
    t13 = (t7 + 4);
    t14 = *((unsigned int *)t7);
    *((unsigned int *)t7) = (t14 | t8);
    t15 = *((unsigned int *)t13);
    *((unsigned int *)t13) = (t15 | t9);
    xsi_driver_vfirst_trans(t3, 0, 0);

LAB1:    return;
}

static void implSig6_execute(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    unsigned int t8;
    unsigned int t9;
    char *t10;
    unsigned int t11;
    unsigned int t12;
    char *t13;
    unsigned int t14;
    unsigned int t15;

LAB0:    t1 = (t0 + 19536U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    t2 = ((char*)((ng4)));
    t3 = (t0 + 23344);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    memset(t7, 0, 8);
    t8 = 1U;
    t9 = t8;
    t10 = (t2 + 4);
    t11 = *((unsigned int *)t2);
    t8 = (t8 & t11);
    t12 = *((unsigned int *)t10);
    t9 = (t9 & t12);
    t13 = (t7 + 4);
    t14 = *((unsigned int *)t7);
    *((unsigned int *)t7) = (t14 | t8);
    t15 = *((unsigned int *)t13);
    *((unsigned int *)t13) = (t15 | t9);
    xsi_driver_vfirst_trans(t3, 0, 0);

LAB1:    return;
}

static void implSig7_execute(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    unsigned int t8;
    unsigned int t9;
    char *t10;
    unsigned int t11;
    unsigned int t12;
    char *t13;
    unsigned int t14;
    unsigned int t15;

LAB0:    t1 = (t0 + 19784U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    t2 = ((char*)((ng3)));
    t3 = (t0 + 23408);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    memset(t7, 0, 8);
    t8 = 1U;
    t9 = t8;
    t10 = (t2 + 4);
    t11 = *((unsigned int *)t2);
    t8 = (t8 & t11);
    t12 = *((unsigned int *)t10);
    t9 = (t9 & t12);
    t13 = (t7 + 4);
    t14 = *((unsigned int *)t7);
    *((unsigned int *)t7) = (t14 | t8);
    t15 = *((unsigned int *)t13);
    *((unsigned int *)t13) = (t15 | t9);
    xsi_driver_vfirst_trans(t3, 0, 0);

LAB1:    return;
}

static void implSig8_execute(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    unsigned int t8;
    unsigned int t9;
    char *t10;
    unsigned int t11;
    unsigned int t12;
    char *t13;
    unsigned int t14;
    unsigned int t15;

LAB0:    t1 = (t0 + 20032U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    t2 = ((char*)((ng4)));
    t3 = (t0 + 23472);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    memset(t7, 0, 8);
    t8 = 1U;
    t9 = t8;
    t10 = (t2 + 4);
    t11 = *((unsigned int *)t2);
    t8 = (t8 & t11);
    t12 = *((unsigned int *)t10);
    t9 = (t9 & t12);
    t13 = (t7 + 4);
    t14 = *((unsigned int *)t7);
    *((unsigned int *)t7) = (t14 | t8);
    t15 = *((unsigned int *)t13);
    *((unsigned int *)t13) = (t15 | t9);
    xsi_driver_vfirst_trans(t3, 0, 0);

LAB1:    return;
}

static void implSig9_execute(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    unsigned int t8;
    unsigned int t9;
    char *t10;
    unsigned int t11;
    unsigned int t12;
    char *t13;
    unsigned int t14;
    unsigned int t15;

LAB0:    t1 = (t0 + 20280U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    t2 = ((char*)((ng3)));
    t3 = (t0 + 23536);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    memset(t7, 0, 8);
    t8 = 1U;
    t9 = t8;
    t10 = (t2 + 4);
    t11 = *((unsigned int *)t2);
    t8 = (t8 & t11);
    t12 = *((unsigned int *)t10);
    t9 = (t9 & t12);
    t13 = (t7 + 4);
    t14 = *((unsigned int *)t7);
    *((unsigned int *)t7) = (t14 | t8);
    t15 = *((unsigned int *)t13);
    *((unsigned int *)t13) = (t15 | t9);
    xsi_driver_vfirst_trans(t3, 0, 0);

LAB1:    return;
}

static void implSig10_execute(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    unsigned int t8;
    unsigned int t9;
    char *t10;
    unsigned int t11;
    unsigned int t12;
    char *t13;
    unsigned int t14;
    unsigned int t15;

LAB0:    t1 = (t0 + 20528U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    t2 = ((char*)((ng3)));
    t3 = (t0 + 23600);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    memset(t7, 0, 8);
    t8 = 1U;
    t9 = t8;
    t10 = (t2 + 4);
    t11 = *((unsigned int *)t2);
    t8 = (t8 & t11);
    t12 = *((unsigned int *)t10);
    t9 = (t9 & t12);
    t13 = (t7 + 4);
    t14 = *((unsigned int *)t7);
    *((unsigned int *)t7) = (t14 | t8);
    t15 = *((unsigned int *)t13);
    *((unsigned int *)t13) = (t15 | t9);
    xsi_driver_vfirst_trans(t3, 0, 0);

LAB1:    return;
}

static void implSig11_execute(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    unsigned int t8;
    unsigned int t9;
    char *t10;
    unsigned int t11;
    unsigned int t12;
    char *t13;
    unsigned int t14;
    unsigned int t15;

LAB0:    t1 = (t0 + 20776U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    t2 = ((char*)((ng4)));
    t3 = (t0 + 23664);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    memset(t7, 0, 8);
    t8 = 1U;
    t9 = t8;
    t10 = (t2 + 4);
    t11 = *((unsigned int *)t2);
    t8 = (t8 & t11);
    t12 = *((unsigned int *)t10);
    t9 = (t9 & t12);
    t13 = (t7 + 4);
    t14 = *((unsigned int *)t7);
    *((unsigned int *)t7) = (t14 | t8);
    t15 = *((unsigned int *)t13);
    *((unsigned int *)t13) = (t15 | t9);
    xsi_driver_vfirst_trans(t3, 0, 0);

LAB1:    return;
}

static void implSig12_execute(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    unsigned int t8;
    unsigned int t9;
    char *t10;
    unsigned int t11;
    unsigned int t12;
    char *t13;
    unsigned int t14;
    unsigned int t15;

LAB0:    t1 = (t0 + 21024U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    t2 = ((char*)((ng4)));
    t3 = (t0 + 23728);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    memset(t7, 0, 8);
    t8 = 1U;
    t9 = t8;
    t10 = (t2 + 4);
    t11 = *((unsigned int *)t2);
    t8 = (t8 & t11);
    t12 = *((unsigned int *)t10);
    t9 = (t9 & t12);
    t13 = (t7 + 4);
    t14 = *((unsigned int *)t7);
    *((unsigned int *)t7) = (t14 | t8);
    t15 = *((unsigned int *)t13);
    *((unsigned int *)t13) = (t15 | t9);
    xsi_driver_vfirst_trans(t3, 0, 0);

LAB1:    return;
}

static void implSig13_execute(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    unsigned int t8;
    unsigned int t9;
    char *t10;
    unsigned int t11;
    unsigned int t12;
    char *t13;
    unsigned int t14;
    unsigned int t15;

LAB0:    t1 = (t0 + 21272U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    t2 = ((char*)((ng3)));
    t3 = (t0 + 23792);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    memset(t7, 0, 8);
    t8 = 1U;
    t9 = t8;
    t10 = (t2 + 4);
    t11 = *((unsigned int *)t2);
    t8 = (t8 & t11);
    t12 = *((unsigned int *)t10);
    t9 = (t9 & t12);
    t13 = (t7 + 4);
    t14 = *((unsigned int *)t7);
    *((unsigned int *)t7) = (t14 | t8);
    t15 = *((unsigned int *)t13);
    *((unsigned int *)t13) = (t15 | t9);
    xsi_driver_vfirst_trans(t3, 0, 0);

LAB1:    return;
}

static void implSig14_execute(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    unsigned int t8;
    unsigned int t9;
    char *t10;
    unsigned int t11;
    unsigned int t12;
    char *t13;
    unsigned int t14;
    unsigned int t15;

LAB0:    t1 = (t0 + 21520U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    t2 = ((char*)((ng3)));
    t3 = (t0 + 23856);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    memset(t7, 0, 8);
    t8 = 1U;
    t9 = t8;
    t10 = (t2 + 4);
    t11 = *((unsigned int *)t2);
    t8 = (t8 & t11);
    t12 = *((unsigned int *)t10);
    t9 = (t9 & t12);
    t13 = (t7 + 4);
    t14 = *((unsigned int *)t7);
    *((unsigned int *)t7) = (t14 | t8);
    t15 = *((unsigned int *)t13);
    *((unsigned int *)t13) = (t15 | t9);
    xsi_driver_vfirst_trans(t3, 0, 0);

LAB1:    return;
}

static void implSig15_execute(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    unsigned int t8;
    unsigned int t9;
    char *t10;
    unsigned int t11;
    unsigned int t12;
    char *t13;
    unsigned int t14;
    unsigned int t15;

LAB0:    t1 = (t0 + 21768U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    t2 = ((char*)((ng3)));
    t3 = (t0 + 23920);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    memset(t7, 0, 8);
    t8 = 1U;
    t9 = t8;
    t10 = (t2 + 4);
    t11 = *((unsigned int *)t2);
    t8 = (t8 & t11);
    t12 = *((unsigned int *)t10);
    t9 = (t9 & t12);
    t13 = (t7 + 4);
    t14 = *((unsigned int *)t7);
    *((unsigned int *)t7) = (t14 | t8);
    t15 = *((unsigned int *)t13);
    *((unsigned int *)t13) = (t15 | t9);
    xsi_driver_vfirst_trans(t3, 0, 0);

LAB1:    return;
}

static void implSig16_execute(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    unsigned int t8;
    unsigned int t9;
    char *t10;
    unsigned int t11;
    unsigned int t12;
    char *t13;
    unsigned int t14;
    unsigned int t15;

LAB0:    t1 = (t0 + 22016U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    t2 = ((char*)((ng3)));
    t3 = (t0 + 23984);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    memset(t7, 0, 8);
    t8 = 1U;
    t9 = t8;
    t10 = (t2 + 4);
    t11 = *((unsigned int *)t2);
    t8 = (t8 & t11);
    t12 = *((unsigned int *)t10);
    t9 = (t9 & t12);
    t13 = (t7 + 4);
    t14 = *((unsigned int *)t7);
    *((unsigned int *)t7) = (t14 | t8);
    t15 = *((unsigned int *)t13);
    *((unsigned int *)t13) = (t15 | t9);
    xsi_driver_vfirst_trans(t3, 0, 0);

LAB1:    return;
}


extern void work_m_00000000000391399872_0477423891_init()
{
	static char *pe[] = {(void *)Always_239_0,(void *)Always_262_1,(void *)Cont_531_2,(void *)Cont_532_3,(void *)Always_592_4,(void *)Always_594_5,(void *)Cont_597_6,(void *)Cont_616_7,(void *)Cont_617_8,(void *)Cont_618_9,(void *)Cont_619_10,(void *)implSig1_execute,(void *)implSig2_execute,(void *)implSig3_execute,(void *)implSig4_execute,(void *)implSig5_execute,(void *)implSig6_execute,(void *)implSig7_execute,(void *)implSig8_execute,(void *)implSig9_execute,(void *)implSig10_execute,(void *)implSig11_execute,(void *)implSig12_execute,(void *)implSig13_execute,(void *)implSig14_execute,(void *)implSig15_execute,(void *)implSig16_execute};
	xsi_register_didat("work_m_00000000000391399872_0477423891", "isim/isim_test.exe.sim/work/m_00000000000391399872_0477423891.didat");
	xsi_register_executes(pe);
}
