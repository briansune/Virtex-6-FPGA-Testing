/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "I:/Xilinx_V6_xc6vlx365t/v6_golden_top_ddr_pwr_400mhz/v6_golden_top_ddr_pwr/ddr_pwr_ip/ddr_pwr_ip/user_design/sim/cmd_prbs_gen.v";
static int ng1[] = {1, 0};
static int ng2[] = {0, 0};
static unsigned int ng3[] = {0U, 0U};
static int ng4[] = {32, 0};
static int ng5[] = {9, 0};
static int ng6[] = {8, 0};
static int ng7[] = {7, 0};
static int ng8[] = {6, 0};
static int ng9[] = {4, 0};
static int ng10[] = {3, 0};
static int ng11[] = {2, 0};
static int ng12[] = {1413830710, 0, 5654866, 0};
static int ng13[] = {1413566006, 0, 1397768530, 0};
static unsigned int ng14[] = {4294966272U, 0U};
static unsigned int ng15[] = {1023U, 0U};
static int ng16[] = {10, 0};
static int ng17[] = {5, 0};



static int sp_logb2(char *t1, char *t2)
{
    char t7[8];
    char t18[8];
    int t0;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    char *t14;
    char *t15;
    char *t16;
    char *t17;
    char *t19;

LAB0:    t0 = 1;
    xsi_set_current_line(151, ng0);

LAB2:    xsi_set_current_line(152, ng0);
    t3 = (t1 + 4816);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = (t1 + 4976);
    xsi_vlogvar_assign_value(t6, t5, 0, 0, 32);
    xsi_set_current_line(153, ng0);
    xsi_set_current_line(153, ng0);
    t3 = ((char*)((ng1)));
    t4 = (t1 + 4656);
    xsi_vlogvar_assign_value(t4, t3, 0, 0, 32);

LAB3:    t3 = (t1 + 4976);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = ((char*)((ng2)));
    memset(t7, 0, 8);
    xsi_vlog_signed_greater(t7, 32, t5, 32, t6, 32);
    t8 = (t7 + 4);
    t9 = *((unsigned int *)t8);
    t10 = (~(t9));
    t11 = *((unsigned int *)t7);
    t12 = (t11 & t10);
    t13 = (t12 != 0);
    if (t13 > 0)
        goto LAB4;

LAB5:    t0 = 0;

LAB1:    return t0;
LAB4:    xsi_set_current_line(154, ng0);
    t14 = (t1 + 4976);
    t15 = (t14 + 56U);
    t16 = *((char **)t15);
    t17 = ((char*)((ng1)));
    memset(t18, 0, 8);
    xsi_vlog_signed_rshift(t18, 32, t16, 32, t17, 32);
    t19 = (t1 + 4976);
    xsi_vlogvar_assign_value(t19, t18, 0, 0, 32);
    xsi_set_current_line(153, ng0);
    t3 = (t1 + 4656);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = ((char*)((ng1)));
    memset(t7, 0, 8);
    xsi_vlog_signed_add(t7, 32, t5, 32, t6, 32);
    t8 = (t1 + 4656);
    xsi_vlogvar_assign_value(t8, t7, 0, 0, 32);
    goto LAB3;

}

static void Cont_99_0(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;

LAB0:    t1 = (t0 + 5896U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(99, ng0);
    t2 = ((char*)((ng3)));
    t3 = (t0 + 7072);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    memcpy(t7, t2, 8);
    xsi_driver_vfirst_trans(t3, 0, 31);

LAB1:    return;
}

static void Always_160_1(char *t0)
{
    char t11[8];
    char t22[8];
    char t23[8];
    char t24[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    unsigned int t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    char *t12;
    char *t13;
    char *t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    char *t21;
    char *t25;
    char *t26;
    char *t27;
    char *t28;
    char *t29;
    char *t30;
    unsigned int t31;
    int t32;
    char *t33;
    unsigned int t34;
    int t35;
    int t36;
    char *t37;
    unsigned int t38;
    int t39;
    int t40;
    unsigned int t41;
    int t42;
    unsigned int t43;
    unsigned int t44;
    int t45;
    int t46;
    unsigned int t47;
    unsigned int t48;
    unsigned int t49;
    unsigned int t50;
    unsigned int t51;
    char *t52;
    char *t53;
    char *t54;
    unsigned int t55;

LAB0:    t1 = (t0 + 6144U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(160, ng0);
    t2 = (t0 + 6960);
    *((int *)t2) = 1;
    t3 = (t0 + 6176);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(160, ng0);

LAB5:    xsi_set_current_line(161, ng0);
    t4 = (t0 + 3136U);
    t5 = *((char **)t4);
    t4 = (t5 + 4);
    t6 = *((unsigned int *)t4);
    t7 = (~(t6));
    t8 = *((unsigned int *)t5);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB6;

LAB7:    xsi_set_current_line(163, ng0);
    t2 = (t0 + 3296U);
    t3 = *((char **)t2);
    t2 = (t3 + 4);
    t6 = *((unsigned int *)t2);
    t7 = (~(t6));
    t8 = *((unsigned int *)t3);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB10;

LAB11:
LAB12:
LAB8:    goto LAB2;

LAB6:    xsi_set_current_line(161, ng0);

LAB9:    xsi_set_current_line(162, ng0);
    t12 = (t0 + 3456U);
    t13 = *((char **)t12);
    xsi_vlogtype_concat(t11, 32, 32, 1U, t13, 32);
    t12 = (t0 + 4336);
    xsi_vlogvar_wait_assign_value(t12, t11, 0, 0, 32, 1000LL);
    goto LAB8;

LAB10:    xsi_set_current_line(163, ng0);

LAB13:    xsi_set_current_line(164, ng0);
    t4 = (t0 + 4336);
    t5 = (t4 + 56U);
    t12 = *((char **)t5);
    memset(t11, 0, 8);
    t13 = (t11 + 4);
    t14 = (t12 + 4);
    t15 = *((unsigned int *)t12);
    t16 = (t15 >> 7);
    *((unsigned int *)t11) = t16;
    t17 = *((unsigned int *)t14);
    t18 = (t17 >> 7);
    *((unsigned int *)t13) = t18;
    t19 = *((unsigned int *)t11);
    *((unsigned int *)t11) = (t19 & 16777215U);
    t20 = *((unsigned int *)t13);
    *((unsigned int *)t13) = (t20 & 16777215U);
    t21 = (t0 + 4336);
    t25 = (t0 + 4336);
    t26 = (t25 + 72U);
    t27 = *((char **)t26);
    t28 = ((char*)((ng4)));
    t29 = ((char*)((ng5)));
    xsi_vlog_convert_partindices(t22, t23, t24, ((int*)(t27)), 2, t28, 32, 1, t29, 32, 1);
    t30 = (t22 + 4);
    t31 = *((unsigned int *)t30);
    t32 = (!(t31));
    t33 = (t23 + 4);
    t34 = *((unsigned int *)t33);
    t35 = (!(t34));
    t36 = (t32 && t35);
    t37 = (t24 + 4);
    t38 = *((unsigned int *)t37);
    t39 = (!(t38));
    t40 = (t36 && t39);
    if (t40 == 1)
        goto LAB14;

LAB15:    xsi_set_current_line(165, ng0);
    t2 = (t0 + 4336);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    memset(t11, 0, 8);
    t5 = (t11 + 4);
    t12 = (t4 + 4);
    t6 = *((unsigned int *)t4);
    t7 = (t6 >> 31);
    t8 = (t7 & 1);
    *((unsigned int *)t11) = t8;
    t9 = *((unsigned int *)t12);
    t10 = (t9 >> 31);
    t15 = (t10 & 1);
    *((unsigned int *)t5) = t15;
    t13 = (t0 + 4336);
    t14 = (t13 + 56U);
    t21 = *((char **)t14);
    memset(t22, 0, 8);
    t25 = (t22 + 4);
    t26 = (t21 + 4);
    t16 = *((unsigned int *)t21);
    t17 = (t16 >> 6);
    t18 = (t17 & 1);
    *((unsigned int *)t22) = t18;
    t19 = *((unsigned int *)t26);
    t20 = (t19 >> 6);
    t31 = (t20 & 1);
    *((unsigned int *)t25) = t31;
    t34 = *((unsigned int *)t11);
    t38 = *((unsigned int *)t22);
    t41 = (t34 ^ t38);
    *((unsigned int *)t23) = t41;
    t27 = (t11 + 4);
    t28 = (t22 + 4);
    t29 = (t23 + 4);
    t43 = *((unsigned int *)t27);
    t44 = *((unsigned int *)t28);
    t47 = (t43 | t44);
    *((unsigned int *)t29) = t47;
    t48 = *((unsigned int *)t29);
    t49 = (t48 != 0);
    if (t49 == 1)
        goto LAB16;

LAB17:
LAB18:    t30 = (t0 + 4336);
    t33 = (t0 + 4336);
    t37 = (t33 + 72U);
    t52 = *((char **)t37);
    t53 = ((char*)((ng6)));
    xsi_vlog_generic_convert_bit_index(t24, t52, 2, t53, 32, 1);
    t54 = (t24 + 4);
    t55 = *((unsigned int *)t54);
    t32 = (!(t55));
    if (t32 == 1)
        goto LAB19;

LAB20:    xsi_set_current_line(166, ng0);
    t2 = (t0 + 4336);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    memset(t11, 0, 8);
    t5 = (t11 + 4);
    t12 = (t4 + 4);
    t6 = *((unsigned int *)t4);
    t7 = (t6 >> 31);
    t8 = (t7 & 1);
    *((unsigned int *)t11) = t8;
    t9 = *((unsigned int *)t12);
    t10 = (t9 >> 31);
    t15 = (t10 & 1);
    *((unsigned int *)t5) = t15;
    t13 = (t0 + 4336);
    t14 = (t13 + 56U);
    t21 = *((char **)t14);
    memset(t22, 0, 8);
    t25 = (t22 + 4);
    t26 = (t21 + 4);
    t16 = *((unsigned int *)t21);
    t17 = (t16 >> 5);
    t18 = (t17 & 1);
    *((unsigned int *)t22) = t18;
    t19 = *((unsigned int *)t26);
    t20 = (t19 >> 5);
    t31 = (t20 & 1);
    *((unsigned int *)t25) = t31;
    t34 = *((unsigned int *)t11);
    t38 = *((unsigned int *)t22);
    t41 = (t34 ^ t38);
    *((unsigned int *)t23) = t41;
    t27 = (t11 + 4);
    t28 = (t22 + 4);
    t29 = (t23 + 4);
    t43 = *((unsigned int *)t27);
    t44 = *((unsigned int *)t28);
    t47 = (t43 | t44);
    *((unsigned int *)t29) = t47;
    t48 = *((unsigned int *)t29);
    t49 = (t48 != 0);
    if (t49 == 1)
        goto LAB21;

LAB22:
LAB23:    t30 = (t0 + 4336);
    t33 = (t0 + 4336);
    t37 = (t33 + 72U);
    t52 = *((char **)t37);
    t53 = ((char*)((ng7)));
    xsi_vlog_generic_convert_bit_index(t24, t52, 2, t53, 32, 1);
    t54 = (t24 + 4);
    t55 = *((unsigned int *)t54);
    t32 = (!(t55));
    if (t32 == 1)
        goto LAB24;

LAB25:    xsi_set_current_line(167, ng0);
    t2 = (t0 + 4336);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    memset(t11, 0, 8);
    t5 = (t11 + 4);
    t12 = (t4 + 4);
    t6 = *((unsigned int *)t4);
    t7 = (t6 >> 2);
    *((unsigned int *)t11) = t7;
    t8 = *((unsigned int *)t12);
    t9 = (t8 >> 2);
    *((unsigned int *)t5) = t9;
    t10 = *((unsigned int *)t11);
    *((unsigned int *)t11) = (t10 & 7U);
    t15 = *((unsigned int *)t5);
    *((unsigned int *)t5) = (t15 & 7U);
    t13 = (t0 + 4336);
    t14 = (t0 + 4336);
    t21 = (t14 + 72U);
    t25 = *((char **)t21);
    t26 = ((char*)((ng8)));
    t27 = ((char*)((ng9)));
    xsi_vlog_convert_partindices(t22, t23, t24, ((int*)(t25)), 2, t26, 32, 1, t27, 32, 1);
    t28 = (t22 + 4);
    t16 = *((unsigned int *)t28);
    t32 = (!(t16));
    t29 = (t23 + 4);
    t17 = *((unsigned int *)t29);
    t35 = (!(t17));
    t36 = (t32 && t35);
    t30 = (t24 + 4);
    t18 = *((unsigned int *)t30);
    t39 = (!(t18));
    t40 = (t36 && t39);
    if (t40 == 1)
        goto LAB26;

LAB27:    xsi_set_current_line(169, ng0);
    t2 = (t0 + 4336);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    memset(t11, 0, 8);
    t5 = (t11 + 4);
    t12 = (t4 + 4);
    t6 = *((unsigned int *)t4);
    t7 = (t6 >> 31);
    t8 = (t7 & 1);
    *((unsigned int *)t11) = t8;
    t9 = *((unsigned int *)t12);
    t10 = (t9 >> 31);
    t15 = (t10 & 1);
    *((unsigned int *)t5) = t15;
    t13 = (t0 + 4336);
    t14 = (t13 + 56U);
    t21 = *((char **)t14);
    memset(t22, 0, 8);
    t25 = (t22 + 4);
    t26 = (t21 + 4);
    t16 = *((unsigned int *)t21);
    t17 = (t16 >> 1);
    t18 = (t17 & 1);
    *((unsigned int *)t22) = t18;
    t19 = *((unsigned int *)t26);
    t20 = (t19 >> 1);
    t31 = (t20 & 1);
    *((unsigned int *)t25) = t31;
    t34 = *((unsigned int *)t11);
    t38 = *((unsigned int *)t22);
    t41 = (t34 ^ t38);
    *((unsigned int *)t23) = t41;
    t27 = (t11 + 4);
    t28 = (t22 + 4);
    t29 = (t23 + 4);
    t43 = *((unsigned int *)t27);
    t44 = *((unsigned int *)t28);
    t47 = (t43 | t44);
    *((unsigned int *)t29) = t47;
    t48 = *((unsigned int *)t29);
    t49 = (t48 != 0);
    if (t49 == 1)
        goto LAB28;

LAB29:
LAB30:    t30 = (t0 + 4336);
    t33 = (t0 + 4336);
    t37 = (t33 + 72U);
    t52 = *((char **)t37);
    t53 = ((char*)((ng10)));
    xsi_vlog_generic_convert_bit_index(t24, t52, 2, t53, 32, 1);
    t54 = (t24 + 4);
    t55 = *((unsigned int *)t54);
    t32 = (!(t55));
    if (t32 == 1)
        goto LAB31;

LAB32:    xsi_set_current_line(170, ng0);
    t2 = (t0 + 4336);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    memset(t11, 0, 8);
    t5 = (t11 + 4);
    t12 = (t4 + 4);
    t6 = *((unsigned int *)t4);
    t7 = (t6 >> 0);
    t8 = (t7 & 1);
    *((unsigned int *)t11) = t8;
    t9 = *((unsigned int *)t12);
    t10 = (t9 >> 0);
    t15 = (t10 & 1);
    *((unsigned int *)t5) = t15;
    t13 = (t0 + 4336);
    t14 = (t0 + 4336);
    t21 = (t14 + 72U);
    t25 = *((char **)t21);
    t26 = ((char*)((ng11)));
    xsi_vlog_generic_convert_bit_index(t22, t25, 2, t26, 32, 1);
    t27 = (t22 + 4);
    t16 = *((unsigned int *)t27);
    t32 = (!(t16));
    if (t32 == 1)
        goto LAB33;

LAB34:    xsi_set_current_line(171, ng0);
    t2 = (t0 + 4336);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    memset(t11, 0, 8);
    t5 = (t11 + 4);
    t12 = (t4 + 4);
    t6 = *((unsigned int *)t4);
    t7 = (t6 >> 31);
    t8 = (t7 & 1);
    *((unsigned int *)t11) = t8;
    t9 = *((unsigned int *)t12);
    t10 = (t9 >> 31);
    t15 = (t10 & 1);
    *((unsigned int *)t5) = t15;
    t13 = (t0 + 4336);
    t14 = (t0 + 4336);
    t21 = (t14 + 72U);
    t25 = *((char **)t21);
    t26 = ((char*)((ng1)));
    xsi_vlog_generic_convert_bit_index(t22, t25, 2, t26, 32, 1);
    t27 = (t22 + 4);
    t16 = *((unsigned int *)t27);
    t32 = (!(t16));
    if (t32 == 1)
        goto LAB35;

LAB36:    goto LAB12;

LAB14:    t41 = *((unsigned int *)t24);
    t42 = (t41 + 0);
    t43 = *((unsigned int *)t22);
    t44 = *((unsigned int *)t23);
    t45 = (t43 - t44);
    t46 = (t45 + 1);
    xsi_vlogvar_wait_assign_value(t21, t11, t42, *((unsigned int *)t23), t46, 1000LL);
    goto LAB15;

LAB16:    t50 = *((unsigned int *)t23);
    t51 = *((unsigned int *)t29);
    *((unsigned int *)t23) = (t50 | t51);
    goto LAB18;

LAB19:    xsi_vlogvar_wait_assign_value(t30, t23, 0, *((unsigned int *)t24), 1, 1000LL);
    goto LAB20;

LAB21:    t50 = *((unsigned int *)t23);
    t51 = *((unsigned int *)t29);
    *((unsigned int *)t23) = (t50 | t51);
    goto LAB23;

LAB24:    xsi_vlogvar_wait_assign_value(t30, t23, 0, *((unsigned int *)t24), 1, 1000LL);
    goto LAB25;

LAB26:    t19 = *((unsigned int *)t24);
    t42 = (t19 + 0);
    t20 = *((unsigned int *)t22);
    t31 = *((unsigned int *)t23);
    t45 = (t20 - t31);
    t46 = (t45 + 1);
    xsi_vlogvar_wait_assign_value(t13, t11, t42, *((unsigned int *)t23), t46, 1000LL);
    goto LAB27;

LAB28:    t50 = *((unsigned int *)t23);
    t51 = *((unsigned int *)t29);
    *((unsigned int *)t23) = (t50 | t51);
    goto LAB30;

LAB31:    xsi_vlogvar_wait_assign_value(t30, t23, 0, *((unsigned int *)t24), 1, 1000LL);
    goto LAB32;

LAB33:    xsi_vlogvar_wait_assign_value(t13, t11, 0, *((unsigned int *)t22), 1, 1000LL);
    goto LAB34;

LAB35:    xsi_vlogvar_wait_assign_value(t13, t11, 0, *((unsigned int *)t22), 1, 1000LL);
    goto LAB36;

}

static void Always_176_2(char *t0)
{
    char t6[16];
    char t30[8];
    char t35[8];
    char t37[8];
    char t38[8];
    char t56[8];
    char t59[8];
    char t67[8];
    char t68[8];
    char t96[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    char *t17;
    char *t18;
    char *t19;
    char *t20;
    char *t21;
    char *t22;
    char *t23;
    char *t24;
    char *t25;
    int t26;
    char *t27;
    char *t28;
    char *t29;
    char *t31;
    char *t32;
    char *t33;
    char *t34;
    char *t36;
    unsigned int t39;
    unsigned int t40;
    unsigned int t41;
    unsigned int t42;
    unsigned int t43;
    unsigned int t44;
    unsigned int t45;
    unsigned int t46;
    unsigned int t47;
    unsigned int t48;
    unsigned int t49;
    unsigned int t50;
    unsigned int t51;
    unsigned int t52;
    unsigned int t53;
    unsigned int t54;
    unsigned int t55;
    char *t57;
    char *t58;
    char *t60;
    char *t61;
    char *t62;
    char *t63;
    char *t64;
    char *t65;
    char *t66;
    unsigned int t69;
    unsigned int t70;
    unsigned int t71;
    char *t72;
    char *t73;
    char *t74;
    unsigned int t75;
    unsigned int t76;
    unsigned int t77;
    unsigned int t78;
    unsigned int t79;
    unsigned int t80;
    unsigned int t81;
    char *t82;
    char *t83;
    unsigned int t84;
    unsigned int t85;
    unsigned int t86;
    unsigned int t87;
    unsigned int t88;
    unsigned int t89;
    int t90;
    unsigned int t91;
    unsigned int t92;
    unsigned int t93;
    unsigned int t94;
    char *t95;
    char *t97;
    char *t98;
    char *t99;
    char *t100;
    char *t101;
    char *t102;
    char *t103;
    unsigned int t104;
    int t105;
    int t106;
    int t107;
    int t108;
    int t109;
    int t110;

LAB0:    t1 = (t0 + 6392U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(176, ng0);
    t2 = (t0 + 6976);
    *((int *)t2) = 1;
    t3 = (t0 + 6424);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(176, ng0);

LAB5:    xsi_set_current_line(178, ng0);
    t4 = ((char*)((ng12)));
    t5 = ((char*)((ng13)));
    xsi_vlog_unsigned_equal(t6, 64, t4, 56, t5, 64);
    t7 = (t6 + 4);
    t8 = *((unsigned int *)t7);
    t9 = (~(t8));
    t10 = *((unsigned int *)t6);
    t11 = (t10 & t9);
    t12 = (t11 != 0);
    if (t12 > 0)
        goto LAB6;

LAB7:    xsi_set_current_line(192, ng0);

LAB44:    xsi_set_current_line(193, ng0);
    xsi_set_current_line(193, ng0);
    t2 = (t0 + 880);
    t3 = *((char **)t2);
    t2 = (t0 + 6200);
    t4 = (t0 + 2344);
    t5 = xsi_create_subprogram_invocation(t2, 0, t0, t4, 0, 0);
    t7 = (t0 + 4816);
    xsi_vlogvar_assign_value(t7, t3, 0, 0, 32);

LAB45:    t13 = (t0 + 6296);
    t14 = *((char **)t13);
    t15 = (t14 + 80U);
    t16 = *((char **)t15);
    t17 = (t16 + 272U);
    t18 = *((char **)t17);
    t19 = (t18 + 0U);
    t20 = *((char **)t19);
    t26 = ((int  (*)(char *, char *))t20)(t0, t14);
    if (t26 != 0)
        goto LAB47;

LAB46:    t14 = (t0 + 6296);
    t21 = *((char **)t14);
    t14 = (t0 + 4656);
    t22 = (t14 + 56U);
    t23 = *((char **)t22);
    memcpy(t30, t23, 8);
    t24 = (t0 + 2344);
    t25 = (t0 + 6200);
    t27 = 0;
    xsi_delete_subprogram_invocation(t24, t21, t0, t25, t27);
    t28 = ((char*)((ng9)));
    memset(t35, 0, 8);
    xsi_vlog_signed_minus(t35, 32, t30, 32, t28, 32);
    t29 = (t0 + 4496);
    xsi_vlogvar_assign_value(t29, t35, 0, 0, 32);

LAB48:    t2 = (t0 + 4496);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 1288);
    t7 = *((char **)t5);
    t5 = ((char*)((ng1)));
    memset(t30, 0, 8);
    xsi_vlog_signed_minus(t30, 32, t7, 32, t5, 32);
    memset(t35, 0, 8);
    xsi_vlog_signed_leq(t35, 32, t4, 32, t30, 32);
    t13 = (t35 + 4);
    t8 = *((unsigned int *)t13);
    t9 = (~(t8));
    t10 = *((unsigned int *)t35);
    t11 = (t10 & t9);
    t12 = (t11 != 0);
    if (t12 > 0)
        goto LAB49;

LAB50:    xsi_set_current_line(200, ng0);
    t2 = ((char*)((ng3)));
    t3 = (t0 + 4176);
    t4 = (t0 + 4176);
    t5 = (t4 + 72U);
    t7 = *((char **)t5);
    t13 = ((char*)((ng17)));
    t14 = ((char*)((ng2)));
    xsi_vlog_convert_partindices(t30, t35, t37, ((int*)(t7)), 2, t13, 32, 1, t14, 32, 1);
    t15 = (t30 + 4);
    t8 = *((unsigned int *)t15);
    t26 = (!(t8));
    t16 = (t35 + 4);
    t9 = *((unsigned int *)t16);
    t90 = (!(t9));
    t105 = (t26 && t90);
    t17 = (t37 + 4);
    t10 = *((unsigned int *)t17);
    t106 = (!(t10));
    t107 = (t105 && t106);
    if (t107 == 1)
        goto LAB77;

LAB78:
LAB8:    goto LAB2;

LAB6:    xsi_set_current_line(178, ng0);

LAB9:    xsi_set_current_line(180, ng0);
    xsi_set_current_line(180, ng0);
    t13 = (t0 + 880);
    t14 = *((char **)t13);
    t13 = (t0 + 6200);
    t15 = (t0 + 2344);
    t16 = xsi_create_subprogram_invocation(t13, 0, t0, t15, 0, 0);
    t17 = (t0 + 4816);
    xsi_vlogvar_assign_value(t17, t14, 0, 0, 32);

LAB10:    t18 = (t0 + 6296);
    t19 = *((char **)t18);
    t20 = (t19 + 80U);
    t21 = *((char **)t20);
    t22 = (t21 + 272U);
    t23 = *((char **)t22);
    t24 = (t23 + 0U);
    t25 = *((char **)t24);
    t26 = ((int  (*)(char *, char *))t25)(t0, t19);
    if (t26 != 0)
        goto LAB12;

LAB11:    t19 = (t0 + 6296);
    t27 = *((char **)t19);
    t19 = (t0 + 4656);
    t28 = (t19 + 56U);
    t29 = *((char **)t28);
    memcpy(t30, t29, 8);
    t31 = (t0 + 2344);
    t32 = (t0 + 6200);
    t33 = 0;
    xsi_delete_subprogram_invocation(t31, t27, t0, t32, t33);
    t34 = ((char*)((ng1)));
    memset(t35, 0, 8);
    xsi_vlog_signed_add(t35, 32, t30, 32, t34, 32);
    t36 = (t0 + 4496);
    xsi_vlogvar_assign_value(t36, t35, 0, 0, 32);

LAB13:    t2 = (t0 + 4496);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 1288);
    t7 = *((char **)t5);
    t5 = ((char*)((ng1)));
    memset(t30, 0, 8);
    xsi_vlog_signed_minus(t30, 32, t7, 32, t5, 32);
    memset(t35, 0, 8);
    xsi_vlog_signed_leq(t35, 32, t4, 32, t30, 32);
    t13 = (t35 + 4);
    t8 = *((unsigned int *)t13);
    t9 = (~(t8));
    t10 = *((unsigned int *)t35);
    t11 = (t10 & t9);
    t12 = (t11 != 0);
    if (t12 > 0)
        goto LAB14;

LAB15:    xsi_set_current_line(189, ng0);
    t2 = ((char*)((ng3)));
    t3 = (t0 + 4176);
    t4 = (t0 + 4176);
    t5 = (t4 + 72U);
    t7 = *((char **)t5);
    t13 = ((char*)((ng16)));
    t14 = ((char*)((ng2)));
    xsi_vlog_convert_partindices(t30, t35, t37, ((int*)(t7)), 2, t13, 32, 1, t14, 32, 1);
    t15 = (t30 + 4);
    t8 = *((unsigned int *)t15);
    t26 = (!(t8));
    t16 = (t35 + 4);
    t9 = *((unsigned int *)t16);
    t90 = (!(t9));
    t105 = (t26 && t90);
    t17 = (t37 + 4);
    t10 = *((unsigned int *)t17);
    t106 = (!(t10));
    t107 = (t105 && t106);
    if (t107 == 1)
        goto LAB42;

LAB43:    goto LAB8;

LAB12:    t18 = (t0 + 6392U);
    *((char **)t18) = &&LAB10;
    goto LAB1;

LAB14:    xsi_set_current_line(182, ng0);
    t14 = ((char*)((ng3)));
    t15 = (t0 + 1504);
    t16 = (t15 + 72U);
    t17 = *((char **)t16);
    t18 = (t0 + 4496);
    t19 = (t18 + 56U);
    t20 = *((char **)t19);
    xsi_vlog_generic_get_index_select_value(t37, 32, t14, t17, 2, t20, 32, 1);
    t21 = ((char*)((ng1)));
    memset(t38, 0, 8);
    t22 = (t37 + 4);
    t23 = (t21 + 4);
    t39 = *((unsigned int *)t37);
    t40 = *((unsigned int *)t21);
    t41 = (t39 ^ t40);
    t42 = *((unsigned int *)t22);
    t43 = *((unsigned int *)t23);
    t44 = (t42 ^ t43);
    t45 = (t41 | t44);
    t46 = *((unsigned int *)t22);
    t47 = *((unsigned int *)t23);
    t48 = (t46 | t47);
    t49 = (~(t48));
    t50 = (t45 & t49);
    if (t50 != 0)
        goto LAB19;

LAB16:    if (t48 != 0)
        goto LAB18;

LAB17:    *((unsigned int *)t38) = 1;

LAB19:    t25 = (t38 + 4);
    t51 = *((unsigned int *)t25);
    t52 = (~(t51));
    t53 = *((unsigned int *)t38);
    t54 = (t53 & t52);
    t55 = (t54 != 0);
    if (t55 > 0)
        goto LAB20;

LAB21:    xsi_set_current_line(184, ng0);
    t2 = ((char*)((ng14)));
    t3 = (t0 + 1368);
    t4 = (t3 + 72U);
    t5 = *((char **)t4);
    t7 = (t0 + 4496);
    t13 = (t7 + 56U);
    t14 = *((char **)t13);
    xsi_vlog_generic_get_index_select_value(t30, 32, t2, t5, 2, t14, 32, 1);
    t15 = ((char*)((ng1)));
    memset(t35, 0, 8);
    t16 = (t30 + 4);
    t17 = (t15 + 4);
    t8 = *((unsigned int *)t30);
    t9 = *((unsigned int *)t15);
    t10 = (t8 ^ t9);
    t11 = *((unsigned int *)t16);
    t12 = *((unsigned int *)t17);
    t39 = (t11 ^ t12);
    t40 = (t10 | t39);
    t41 = *((unsigned int *)t16);
    t42 = *((unsigned int *)t17);
    t43 = (t41 | t42);
    t44 = (~(t43));
    t45 = (t40 & t44);
    if (t45 != 0)
        goto LAB31;

LAB28:    if (t43 != 0)
        goto LAB30;

LAB29:    *((unsigned int *)t35) = 1;

LAB31:    t19 = (t35 + 4);
    t46 = *((unsigned int *)t19);
    t47 = (~(t46));
    t48 = *((unsigned int *)t35);
    t49 = (t48 & t47);
    t50 = (t49 != 0);
    if (t50 > 0)
        goto LAB32;

LAB33:    xsi_set_current_line(187, ng0);
    t2 = (t0 + 4336);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 4336);
    t7 = (t5 + 72U);
    t13 = *((char **)t7);
    t14 = (t0 + 4496);
    t15 = (t14 + 56U);
    t16 = *((char **)t15);
    t17 = ((char*)((ng1)));
    memset(t35, 0, 8);
    xsi_vlog_signed_add(t35, 32, t16, 32, t17, 32);
    xsi_vlog_generic_get_index_select_value(t30, 1, t4, t13, 2, t35, 32, 1);
    t18 = (t0 + 4176);
    t19 = (t0 + 4176);
    t20 = (t19 + 72U);
    t21 = *((char **)t20);
    t22 = (t0 + 4496);
    t23 = (t22 + 56U);
    t24 = *((char **)t23);
    xsi_vlog_generic_convert_bit_index(t37, t21, 2, t24, 32, 1);
    t25 = (t37 + 4);
    t8 = *((unsigned int *)t25);
    t26 = (!(t8));
    if (t26 == 1)
        goto LAB40;

LAB41:
LAB34:
LAB22:    xsi_set_current_line(180, ng0);
    t2 = (t0 + 4496);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = ((char*)((ng1)));
    memset(t30, 0, 8);
    xsi_vlog_signed_add(t30, 32, t4, 32, t5, 32);
    t7 = (t0 + 4496);
    xsi_vlogvar_assign_value(t7, t30, 0, 0, 32);
    goto LAB13;

LAB18:    t24 = (t38 + 4);
    *((unsigned int *)t38) = 1;
    *((unsigned int *)t24) = 1;
    goto LAB19;

LAB20:    xsi_set_current_line(183, ng0);
    t27 = ((char*)((ng3)));
    t28 = (t0 + 1776);
    t29 = (t28 + 72U);
    t31 = *((char **)t29);
    t32 = (t0 + 4496);
    t33 = (t32 + 56U);
    t34 = *((char **)t33);
    xsi_vlog_generic_get_index_select_value(t56, 1, t27, t31, 2, t34, 32, 1);
    t36 = (t0 + 4336);
    t57 = (t36 + 56U);
    t58 = *((char **)t57);
    t60 = (t0 + 4336);
    t61 = (t60 + 72U);
    t62 = *((char **)t61);
    t63 = (t0 + 4496);
    t64 = (t63 + 56U);
    t65 = *((char **)t64);
    t66 = ((char*)((ng1)));
    memset(t67, 0, 8);
    xsi_vlog_signed_add(t67, 32, t65, 32, t66, 32);
    xsi_vlog_generic_get_index_select_value(t59, 1, t58, t62, 2, t67, 32, 1);
    t69 = *((unsigned int *)t56);
    t70 = *((unsigned int *)t59);
    t71 = (t69 | t70);
    *((unsigned int *)t68) = t71;
    t72 = (t56 + 4);
    t73 = (t59 + 4);
    t74 = (t68 + 4);
    t75 = *((unsigned int *)t72);
    t76 = *((unsigned int *)t73);
    t77 = (t75 | t76);
    *((unsigned int *)t74) = t77;
    t78 = *((unsigned int *)t74);
    t79 = (t78 != 0);
    if (t79 == 1)
        goto LAB23;

LAB24:
LAB25:    t95 = (t0 + 4176);
    t97 = (t0 + 4176);
    t98 = (t97 + 72U);
    t99 = *((char **)t98);
    t100 = (t0 + 4496);
    t101 = (t100 + 56U);
    t102 = *((char **)t101);
    xsi_vlog_generic_convert_bit_index(t96, t99, 2, t102, 32, 1);
    t103 = (t96 + 4);
    t104 = *((unsigned int *)t103);
    t105 = (!(t104));
    if (t105 == 1)
        goto LAB26;

LAB27:    goto LAB22;

LAB23:    t80 = *((unsigned int *)t68);
    t81 = *((unsigned int *)t74);
    *((unsigned int *)t68) = (t80 | t81);
    t82 = (t56 + 4);
    t83 = (t59 + 4);
    t84 = *((unsigned int *)t82);
    t85 = (~(t84));
    t86 = *((unsigned int *)t56);
    t26 = (t86 & t85);
    t87 = *((unsigned int *)t83);
    t88 = (~(t87));
    t89 = *((unsigned int *)t59);
    t90 = (t89 & t88);
    t91 = (~(t26));
    t92 = (~(t90));
    t93 = *((unsigned int *)t74);
    *((unsigned int *)t74) = (t93 & t91);
    t94 = *((unsigned int *)t74);
    *((unsigned int *)t74) = (t94 & t92);
    goto LAB25;

LAB26:    xsi_vlogvar_assign_value(t95, t68, 0, *((unsigned int *)t96), 1);
    goto LAB27;

LAB30:    t18 = (t35 + 4);
    *((unsigned int *)t35) = 1;
    *((unsigned int *)t18) = 1;
    goto LAB31;

LAB32:    xsi_set_current_line(185, ng0);
    t20 = ((char*)((ng15)));
    t21 = (t0 + 1640);
    t22 = (t21 + 72U);
    t23 = *((char **)t22);
    t24 = (t0 + 4496);
    t25 = (t24 + 56U);
    t27 = *((char **)t25);
    xsi_vlog_generic_get_index_select_value(t37, 1, t20, t23, 2, t27, 32, 1);
    t28 = (t0 + 4336);
    t29 = (t28 + 56U);
    t31 = *((char **)t29);
    t32 = (t0 + 4336);
    t33 = (t32 + 72U);
    t34 = *((char **)t33);
    t36 = (t0 + 4496);
    t57 = (t36 + 56U);
    t58 = *((char **)t57);
    t60 = ((char*)((ng1)));
    memset(t56, 0, 8);
    xsi_vlog_signed_add(t56, 32, t58, 32, t60, 32);
    xsi_vlog_generic_get_index_select_value(t38, 1, t31, t34, 2, t56, 32, 1);
    t51 = *((unsigned int *)t37);
    t52 = *((unsigned int *)t38);
    t53 = (t51 & t52);
    *((unsigned int *)t59) = t53;
    t61 = (t37 + 4);
    t62 = (t38 + 4);
    t63 = (t59 + 4);
    t54 = *((unsigned int *)t61);
    t55 = *((unsigned int *)t62);
    t69 = (t54 | t55);
    *((unsigned int *)t63) = t69;
    t70 = *((unsigned int *)t63);
    t71 = (t70 != 0);
    if (t71 == 1)
        goto LAB35;

LAB36:
LAB37:    t66 = (t0 + 4176);
    t72 = (t0 + 4176);
    t73 = (t72 + 72U);
    t74 = *((char **)t73);
    t82 = (t0 + 4496);
    t83 = (t82 + 56U);
    t95 = *((char **)t83);
    xsi_vlog_generic_convert_bit_index(t67, t74, 2, t95, 32, 1);
    t97 = (t67 + 4);
    t94 = *((unsigned int *)t97);
    t105 = (!(t94));
    if (t105 == 1)
        goto LAB38;

LAB39:    goto LAB34;

LAB35:    t75 = *((unsigned int *)t59);
    t76 = *((unsigned int *)t63);
    *((unsigned int *)t59) = (t75 | t76);
    t64 = (t37 + 4);
    t65 = (t38 + 4);
    t77 = *((unsigned int *)t37);
    t78 = (~(t77));
    t79 = *((unsigned int *)t64);
    t80 = (~(t79));
    t81 = *((unsigned int *)t38);
    t84 = (~(t81));
    t85 = *((unsigned int *)t65);
    t86 = (~(t85));
    t26 = (t78 & t80);
    t90 = (t84 & t86);
    t87 = (~(t26));
    t88 = (~(t90));
    t89 = *((unsigned int *)t63);
    *((unsigned int *)t63) = (t89 & t87);
    t91 = *((unsigned int *)t63);
    *((unsigned int *)t63) = (t91 & t88);
    t92 = *((unsigned int *)t59);
    *((unsigned int *)t59) = (t92 & t87);
    t93 = *((unsigned int *)t59);
    *((unsigned int *)t59) = (t93 & t88);
    goto LAB37;

LAB38:    xsi_vlogvar_assign_value(t66, t59, 0, *((unsigned int *)t67), 1);
    goto LAB39;

LAB40:    xsi_vlogvar_assign_value(t18, t30, 0, *((unsigned int *)t37), 1);
    goto LAB41;

LAB42:    t11 = *((unsigned int *)t37);
    t108 = (t11 + 0);
    t12 = *((unsigned int *)t30);
    t39 = *((unsigned int *)t35);
    t109 = (t12 - t39);
    t110 = (t109 + 1);
    xsi_vlogvar_assign_value(t3, t2, t108, *((unsigned int *)t35), t110);
    goto LAB43;

LAB47:    t13 = (t0 + 6392U);
    *((char **)t13) = &&LAB45;
    goto LAB1;

LAB49:    xsi_set_current_line(194, ng0);
    t14 = ((char*)((ng3)));
    t15 = (t0 + 1504);
    t16 = (t15 + 72U);
    t17 = *((char **)t16);
    t18 = (t0 + 4496);
    t19 = (t18 + 56U);
    t20 = *((char **)t19);
    xsi_vlog_generic_get_index_select_value(t37, 32, t14, t17, 2, t20, 32, 1);
    t21 = ((char*)((ng1)));
    memset(t38, 0, 8);
    t22 = (t37 + 4);
    t23 = (t21 + 4);
    t39 = *((unsigned int *)t37);
    t40 = *((unsigned int *)t21);
    t41 = (t39 ^ t40);
    t42 = *((unsigned int *)t22);
    t43 = *((unsigned int *)t23);
    t44 = (t42 ^ t43);
    t45 = (t41 | t44);
    t46 = *((unsigned int *)t22);
    t47 = *((unsigned int *)t23);
    t48 = (t46 | t47);
    t49 = (~(t48));
    t50 = (t45 & t49);
    if (t50 != 0)
        goto LAB54;

LAB51:    if (t48 != 0)
        goto LAB53;

LAB52:    *((unsigned int *)t38) = 1;

LAB54:    t25 = (t38 + 4);
    t51 = *((unsigned int *)t25);
    t52 = (~(t51));
    t53 = *((unsigned int *)t38);
    t54 = (t53 & t52);
    t55 = (t54 != 0);
    if (t55 > 0)
        goto LAB55;

LAB56:    xsi_set_current_line(196, ng0);
    t2 = ((char*)((ng14)));
    t3 = (t0 + 1368);
    t4 = (t3 + 72U);
    t5 = *((char **)t4);
    t7 = (t0 + 4496);
    t13 = (t7 + 56U);
    t14 = *((char **)t13);
    xsi_vlog_generic_get_index_select_value(t30, 32, t2, t5, 2, t14, 32, 1);
    t15 = ((char*)((ng1)));
    memset(t35, 0, 8);
    t16 = (t30 + 4);
    t17 = (t15 + 4);
    t8 = *((unsigned int *)t30);
    t9 = *((unsigned int *)t15);
    t10 = (t8 ^ t9);
    t11 = *((unsigned int *)t16);
    t12 = *((unsigned int *)t17);
    t39 = (t11 ^ t12);
    t40 = (t10 | t39);
    t41 = *((unsigned int *)t16);
    t42 = *((unsigned int *)t17);
    t43 = (t41 | t42);
    t44 = (~(t43));
    t45 = (t40 & t44);
    if (t45 != 0)
        goto LAB66;

LAB63:    if (t43 != 0)
        goto LAB65;

LAB64:    *((unsigned int *)t35) = 1;

LAB66:    t19 = (t35 + 4);
    t46 = *((unsigned int *)t19);
    t47 = (~(t46));
    t48 = *((unsigned int *)t35);
    t49 = (t48 & t47);
    t50 = (t49 != 0);
    if (t50 > 0)
        goto LAB67;

LAB68:    xsi_set_current_line(199, ng0);
    t2 = (t0 + 4336);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 4336);
    t7 = (t5 + 72U);
    t13 = *((char **)t7);
    t14 = (t0 + 4496);
    t15 = (t14 + 56U);
    t16 = *((char **)t15);
    t17 = ((char*)((ng1)));
    memset(t35, 0, 8);
    xsi_vlog_signed_add(t35, 32, t16, 32, t17, 32);
    xsi_vlog_generic_get_index_select_value(t30, 1, t4, t13, 2, t35, 32, 1);
    t18 = (t0 + 4176);
    t19 = (t0 + 4176);
    t20 = (t19 + 72U);
    t21 = *((char **)t20);
    t22 = (t0 + 4496);
    t23 = (t22 + 56U);
    t24 = *((char **)t23);
    xsi_vlog_generic_convert_bit_index(t37, t21, 2, t24, 32, 1);
    t25 = (t37 + 4);
    t8 = *((unsigned int *)t25);
    t26 = (!(t8));
    if (t26 == 1)
        goto LAB75;

LAB76:
LAB69:
LAB57:    xsi_set_current_line(193, ng0);
    t2 = (t0 + 4496);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = ((char*)((ng1)));
    memset(t30, 0, 8);
    xsi_vlog_signed_add(t30, 32, t4, 32, t5, 32);
    t7 = (t0 + 4496);
    xsi_vlogvar_assign_value(t7, t30, 0, 0, 32);
    goto LAB48;

LAB53:    t24 = (t38 + 4);
    *((unsigned int *)t38) = 1;
    *((unsigned int *)t24) = 1;
    goto LAB54;

LAB55:    xsi_set_current_line(195, ng0);
    t27 = ((char*)((ng3)));
    t28 = (t0 + 1776);
    t29 = (t28 + 72U);
    t31 = *((char **)t29);
    t32 = (t0 + 4496);
    t33 = (t32 + 56U);
    t34 = *((char **)t33);
    xsi_vlog_generic_get_index_select_value(t56, 1, t27, t31, 2, t34, 32, 1);
    t36 = (t0 + 4336);
    t57 = (t36 + 56U);
    t58 = *((char **)t57);
    t60 = (t0 + 4336);
    t61 = (t60 + 72U);
    t62 = *((char **)t61);
    t63 = (t0 + 4496);
    t64 = (t63 + 56U);
    t65 = *((char **)t64);
    t66 = ((char*)((ng1)));
    memset(t67, 0, 8);
    xsi_vlog_signed_add(t67, 32, t65, 32, t66, 32);
    xsi_vlog_generic_get_index_select_value(t59, 1, t58, t62, 2, t67, 32, 1);
    t69 = *((unsigned int *)t56);
    t70 = *((unsigned int *)t59);
    t71 = (t69 | t70);
    *((unsigned int *)t68) = t71;
    t72 = (t56 + 4);
    t73 = (t59 + 4);
    t74 = (t68 + 4);
    t75 = *((unsigned int *)t72);
    t76 = *((unsigned int *)t73);
    t77 = (t75 | t76);
    *((unsigned int *)t74) = t77;
    t78 = *((unsigned int *)t74);
    t79 = (t78 != 0);
    if (t79 == 1)
        goto LAB58;

LAB59:
LAB60:    t95 = (t0 + 4176);
    t97 = (t0 + 4176);
    t98 = (t97 + 72U);
    t99 = *((char **)t98);
    t100 = (t0 + 4496);
    t101 = (t100 + 56U);
    t102 = *((char **)t101);
    xsi_vlog_generic_convert_bit_index(t96, t99, 2, t102, 32, 1);
    t103 = (t96 + 4);
    t104 = *((unsigned int *)t103);
    t105 = (!(t104));
    if (t105 == 1)
        goto LAB61;

LAB62:    goto LAB57;

LAB58:    t80 = *((unsigned int *)t68);
    t81 = *((unsigned int *)t74);
    *((unsigned int *)t68) = (t80 | t81);
    t82 = (t56 + 4);
    t83 = (t59 + 4);
    t84 = *((unsigned int *)t82);
    t85 = (~(t84));
    t86 = *((unsigned int *)t56);
    t26 = (t86 & t85);
    t87 = *((unsigned int *)t83);
    t88 = (~(t87));
    t89 = *((unsigned int *)t59);
    t90 = (t89 & t88);
    t91 = (~(t26));
    t92 = (~(t90));
    t93 = *((unsigned int *)t74);
    *((unsigned int *)t74) = (t93 & t91);
    t94 = *((unsigned int *)t74);
    *((unsigned int *)t74) = (t94 & t92);
    goto LAB60;

LAB61:    xsi_vlogvar_assign_value(t95, t68, 0, *((unsigned int *)t96), 1);
    goto LAB62;

LAB65:    t18 = (t35 + 4);
    *((unsigned int *)t35) = 1;
    *((unsigned int *)t18) = 1;
    goto LAB66;

LAB67:    xsi_set_current_line(197, ng0);
    t20 = ((char*)((ng15)));
    t21 = (t0 + 1640);
    t22 = (t21 + 72U);
    t23 = *((char **)t22);
    t24 = (t0 + 4496);
    t25 = (t24 + 56U);
    t27 = *((char **)t25);
    xsi_vlog_generic_get_index_select_value(t37, 1, t20, t23, 2, t27, 32, 1);
    t28 = (t0 + 4336);
    t29 = (t28 + 56U);
    t31 = *((char **)t29);
    t32 = (t0 + 4336);
    t33 = (t32 + 72U);
    t34 = *((char **)t33);
    t36 = (t0 + 4496);
    t57 = (t36 + 56U);
    t58 = *((char **)t57);
    t60 = ((char*)((ng1)));
    memset(t56, 0, 8);
    xsi_vlog_signed_add(t56, 32, t58, 32, t60, 32);
    xsi_vlog_generic_get_index_select_value(t38, 1, t31, t34, 2, t56, 32, 1);
    t51 = *((unsigned int *)t37);
    t52 = *((unsigned int *)t38);
    t53 = (t51 & t52);
    *((unsigned int *)t59) = t53;
    t61 = (t37 + 4);
    t62 = (t38 + 4);
    t63 = (t59 + 4);
    t54 = *((unsigned int *)t61);
    t55 = *((unsigned int *)t62);
    t69 = (t54 | t55);
    *((unsigned int *)t63) = t69;
    t70 = *((unsigned int *)t63);
    t71 = (t70 != 0);
    if (t71 == 1)
        goto LAB70;

LAB71:
LAB72:    t66 = (t0 + 4176);
    t72 = (t0 + 4176);
    t73 = (t72 + 72U);
    t74 = *((char **)t73);
    t82 = (t0 + 4496);
    t83 = (t82 + 56U);
    t95 = *((char **)t83);
    xsi_vlog_generic_convert_bit_index(t67, t74, 2, t95, 32, 1);
    t97 = (t67 + 4);
    t94 = *((unsigned int *)t97);
    t105 = (!(t94));
    if (t105 == 1)
        goto LAB73;

LAB74:    goto LAB69;

LAB70:    t75 = *((unsigned int *)t59);
    t76 = *((unsigned int *)t63);
    *((unsigned int *)t59) = (t75 | t76);
    t64 = (t37 + 4);
    t65 = (t38 + 4);
    t77 = *((unsigned int *)t37);
    t78 = (~(t77));
    t79 = *((unsigned int *)t64);
    t80 = (~(t79));
    t81 = *((unsigned int *)t38);
    t84 = (~(t81));
    t85 = *((unsigned int *)t65);
    t86 = (~(t85));
    t26 = (t78 & t80);
    t90 = (t84 & t86);
    t87 = (~(t26));
    t88 = (~(t90));
    t89 = *((unsigned int *)t63);
    *((unsigned int *)t63) = (t89 & t87);
    t91 = *((unsigned int *)t63);
    *((unsigned int *)t63) = (t91 & t88);
    t92 = *((unsigned int *)t59);
    *((unsigned int *)t59) = (t92 & t87);
    t93 = *((unsigned int *)t59);
    *((unsigned int *)t59) = (t93 & t88);
    goto LAB72;

LAB73:    xsi_vlogvar_assign_value(t66, t59, 0, *((unsigned int *)t67), 1);
    goto LAB74;

LAB75:    xsi_vlogvar_assign_value(t18, t30, 0, *((unsigned int *)t37), 1);
    goto LAB76;

LAB77:    t11 = *((unsigned int *)t37);
    t108 = (t11 + 0);
    t12 = *((unsigned int *)t30);
    t39 = *((unsigned int *)t35);
    t109 = (t12 - t39);
    t110 = (t109 + 1);
    xsi_vlogvar_assign_value(t3, t2, t108, *((unsigned int *)t35), t110);
    goto LAB78;

}

static void Cont_249_3(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;

LAB0:    t1 = (t0 + 6640U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(249, ng0);
    t2 = (t0 + 4176);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 7136);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t4, 8);
    xsi_driver_vfirst_trans(t5, 0, 31);
    t10 = (t0 + 6992);
    *((int *)t10) = 1;

LAB1:    return;
}


extern void work_m_00000000001145982603_1331092202_init()
{
	static char *pe[] = {(void *)Cont_99_0,(void *)Always_160_1,(void *)Always_176_2,(void *)Cont_249_3};
	static char *se[] = {(void *)sp_logb2};
	xsi_register_didat("work_m_00000000001145982603_1331092202", "isim/isim_test.exe.sim/work/m_00000000001145982603_1331092202.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}
