/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "I:/Xilinx_V6_xc6vlx365t/v6_golden_top_ddr_pwr_400mhz/v6_golden_top_ddr_pwr/ddr_pwr_ip/ddr_pwr_ip/user_design/rtl/controller/mc.v";
static int ng1[] = {0, 0};
static int ng2[] = {1, 0};
static unsigned int ng3[] = {0U, 0U};



static int sp_cdiv(char *t1, char *t2)
{
    char t9[8];
    char t10[8];
    char t11[8];
    char t18[8];
    char t20[8];
    char t38[8];
    int t0;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    char *t17;
    char *t19;
    char *t21;
    unsigned int t22;
    unsigned int t23;
    unsigned int t24;
    unsigned int t25;
    unsigned int t26;
    char *t27;
    char *t28;
    unsigned int t29;
    unsigned int t30;
    unsigned int t31;
    char *t32;
    unsigned int t33;
    unsigned int t34;
    unsigned int t35;
    unsigned int t36;
    char *t37;
    char *t39;

LAB0:    t0 = 1;
    xsi_set_current_line(145, ng0);

LAB2:    xsi_set_current_line(146, ng0);
    t3 = (t1 + 32120);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = (t1 + 32280);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    memset(t9, 0, 8);
    xsi_vlog_signed_divide(t9, 32, t5, 32, t8, 32);
    t12 = (t1 + 32120);
    t13 = (t12 + 56U);
    t14 = *((char **)t13);
    t15 = (t1 + 32280);
    t16 = (t15 + 56U);
    t17 = *((char **)t16);
    memset(t18, 0, 8);
    xsi_vlog_signed_mod(t18, 32, t14, 32, t17, 32);
    t19 = ((char*)((ng1)));
    memset(t20, 0, 8);
    xsi_vlog_signed_greater(t20, 32, t18, 32, t19, 32);
    memset(t11, 0, 8);
    t21 = (t20 + 4);
    t22 = *((unsigned int *)t21);
    t23 = (~(t22));
    t24 = *((unsigned int *)t20);
    t25 = (t24 & t23);
    t26 = (t25 & 1U);
    if (t26 != 0)
        goto LAB3;

LAB4:    if (*((unsigned int *)t21) != 0)
        goto LAB5;

LAB6:    t28 = (t11 + 4);
    t29 = *((unsigned int *)t11);
    t30 = *((unsigned int *)t28);
    t31 = (t29 || t30);
    if (t31 > 0)
        goto LAB7;

LAB8:    t33 = *((unsigned int *)t11);
    t34 = (~(t33));
    t35 = *((unsigned int *)t28);
    t36 = (t34 || t35);
    if (t36 > 0)
        goto LAB9;

LAB10:    if (*((unsigned int *)t28) > 0)
        goto LAB11;

LAB12:    if (*((unsigned int *)t11) > 0)
        goto LAB13;

LAB14:    memcpy(t10, t37, 8);

LAB15:    memset(t38, 0, 8);
    xsi_vlog_signed_add(t38, 32, t9, 32, t10, 32);
    t39 = (t1 + 32440);
    xsi_vlogvar_assign_value(t39, t38, 0, 0, 32);
    t0 = 0;

LAB1:    return t0;
LAB3:    *((unsigned int *)t11) = 1;
    goto LAB6;

LAB5:    t27 = (t11 + 4);
    *((unsigned int *)t11) = 1;
    *((unsigned int *)t27) = 1;
    goto LAB6;

LAB7:    t32 = ((char*)((ng2)));
    goto LAB8;

LAB9:    t37 = ((char*)((ng1)));
    goto LAB10;

LAB11:    xsi_vlog_unsigned_bit_combine(t10, 32, t32, 32, t37, 32);
    goto LAB15;

LAB13:    memcpy(t10, t32, 8);
    goto LAB15;

}

static void Always_315_0(char *t0)
{
    char t4[8];
    char t7[8];
    char *t1;
    char *t2;
    char *t3;
    char *t5;
    char *t6;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    char *t18;

LAB0:    t1 = (t0 + 33360U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(315, ng0);
    t2 = (t0 + 35416);
    *((int *)t2) = 1;
    t3 = (t0 + 33392);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(315, ng0);

LAB5:    xsi_set_current_line(316, ng0);
    t5 = (t0 + 15080U);
    t6 = *((char **)t5);
    t5 = (t0 + 27800);
    t8 = (t5 + 56U);
    t9 = *((char **)t8);
    memset(t7, 0, 8);
    t10 = (t7 + 4);
    t11 = (t9 + 4);
    t12 = *((unsigned int *)t9);
    t13 = (t12 >> 0);
    *((unsigned int *)t7) = t13;
    t14 = *((unsigned int *)t11);
    t15 = (t14 >> 0);
    *((unsigned int *)t10) = t15;
    t16 = *((unsigned int *)t7);
    *((unsigned int *)t7) = (t16 & 511U);
    t17 = *((unsigned int *)t10);
    *((unsigned int *)t10) = (t17 & 511U);
    xsi_vlogtype_concat(t4, 10, 10, 2U, t7, 9, t6, 1);
    t18 = (t0 + 27800);
    xsi_vlogvar_wait_assign_value(t18, t4, 0, 0, 10, 0LL);
    goto LAB2;

}

static void Always_319_1(char *t0)
{
    char t7[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t8;
    char *t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    char *t16;

LAB0:    t1 = (t0 + 33608U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(319, ng0);
    t2 = (t0 + 35432);
    *((int *)t2) = 1;
    t3 = (t0 + 33640);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(319, ng0);

LAB5:    xsi_set_current_line(320, ng0);
    t4 = (t0 + 27800);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    memset(t7, 0, 8);
    t8 = (t7 + 4);
    t9 = (t6 + 4);
    t10 = *((unsigned int *)t6);
    t11 = (t10 >> 9);
    t12 = (t11 & 1);
    *((unsigned int *)t7) = t12;
    t13 = *((unsigned int *)t9);
    t14 = (t13 >> 9);
    t15 = (t14 & 1);
    *((unsigned int *)t8) = t15;
    t16 = (t0 + 27960);
    xsi_vlogvar_wait_assign_value(t16, t7, 0, 0, 1, 0LL);
    goto LAB2;

}

static void Always_428_2(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;

LAB0:    t1 = (t0 + 33856U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(428, ng0);
    t2 = (t0 + 35448);
    *((int *)t2) = 1;
    t3 = (t0 + 33888);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(428, ng0);

LAB5:    xsi_set_current_line(429, ng0);
    t4 = (t0 + 22120U);
    t5 = *((char **)t4);
    t4 = (t0 + 28440);
    xsi_vlogvar_wait_assign_value(t4, t5, 0, 0, 1, 1000LL);
    xsi_set_current_line(430, ng0);
    t2 = (t0 + 22280U);
    t3 = *((char **)t2);
    t2 = (t0 + 28600);
    xsi_vlogvar_wait_assign_value(t2, t3, 0, 0, 1, 1000LL);
    xsi_set_current_line(431, ng0);
    t2 = (t0 + 22440U);
    t3 = *((char **)t2);
    t2 = (t0 + 28760);
    xsi_vlogvar_wait_assign_value(t2, t3, 0, 0, 1, 1000LL);
    xsi_set_current_line(432, ng0);
    t2 = (t0 + 22600U);
    t3 = *((char **)t2);
    t2 = (t0 + 28920);
    xsi_vlogvar_wait_assign_value(t2, t3, 0, 0, 1, 1000LL);
    xsi_set_current_line(433, ng0);
    t2 = (t0 + 22760U);
    t3 = *((char **)t2);
    t2 = (t0 + 29080);
    xsi_vlogvar_wait_assign_value(t2, t3, 0, 0, 1, 1000LL);
    xsi_set_current_line(434, ng0);
    t2 = (t0 + 22920U);
    t3 = *((char **)t2);
    t2 = (t0 + 29240);
    xsi_vlogvar_wait_assign_value(t2, t3, 0, 0, 1, 1000LL);
    xsi_set_current_line(435, ng0);
    t2 = (t0 + 23080U);
    t3 = *((char **)t2);
    t2 = (t0 + 29400);
    xsi_vlogvar_wait_assign_value(t2, t3, 0, 0, 1, 1000LL);
    xsi_set_current_line(436, ng0);
    t2 = (t0 + 23240U);
    t3 = *((char **)t2);
    t2 = (t0 + 29560);
    xsi_vlogvar_wait_assign_value(t2, t3, 0, 0, 1, 1000LL);
    xsi_set_current_line(437, ng0);
    t2 = (t0 + 23400U);
    t3 = *((char **)t2);
    t2 = (t0 + 29720);
    xsi_vlogvar_wait_assign_value(t2, t3, 0, 0, 1, 1000LL);
    xsi_set_current_line(438, ng0);
    t2 = (t0 + 23560U);
    t3 = *((char **)t2);
    t2 = (t0 + 29880);
    xsi_vlogvar_wait_assign_value(t2, t3, 0, 0, 1, 1000LL);
    xsi_set_current_line(439, ng0);
    t2 = (t0 + 23720U);
    t3 = *((char **)t2);
    t2 = (t0 + 30040);
    xsi_vlogvar_wait_assign_value(t2, t3, 0, 0, 1, 1000LL);
    xsi_set_current_line(440, ng0);
    t2 = (t0 + 23880U);
    t3 = *((char **)t2);
    t2 = (t0 + 30200);
    xsi_vlogvar_wait_assign_value(t2, t3, 0, 0, 1, 1000LL);
    xsi_set_current_line(441, ng0);
    t2 = (t0 + 24040U);
    t3 = *((char **)t2);
    t2 = (t0 + 30360);
    xsi_vlogvar_wait_assign_value(t2, t3, 0, 0, 3, 1000LL);
    xsi_set_current_line(442, ng0);
    t2 = (t0 + 24200U);
    t3 = *((char **)t2);
    t2 = (t0 + 30520);
    xsi_vlogvar_wait_assign_value(t2, t3, 0, 0, 3, 1000LL);
    xsi_set_current_line(443, ng0);
    t2 = (t0 + 24360U);
    t3 = *((char **)t2);
    t2 = (t0 + 30680);
    xsi_vlogvar_wait_assign_value(t2, t3, 0, 0, 14, 1000LL);
    xsi_set_current_line(444, ng0);
    t2 = (t0 + 24520U);
    t3 = *((char **)t2);
    t2 = (t0 + 30840);
    xsi_vlogvar_wait_assign_value(t2, t3, 0, 0, 14, 1000LL);
    xsi_set_current_line(445, ng0);
    t2 = (t0 + 24680U);
    t3 = *((char **)t2);
    t2 = (t0 + 31000);
    xsi_vlogvar_wait_assign_value(t2, t3, 0, 0, 2, 1000LL);
    xsi_set_current_line(446, ng0);
    t2 = (t0 + 24840U);
    t3 = *((char **)t2);
    t2 = (t0 + 31160);
    xsi_vlogvar_wait_assign_value(t2, t3, 0, 0, 1, 1000LL);
    xsi_set_current_line(447, ng0);
    t2 = (t0 + 25160U);
    t3 = *((char **)t2);
    t2 = (t0 + 31320);
    xsi_vlogvar_wait_assign_value(t2, t3, 0, 0, 8, 1000LL);
    xsi_set_current_line(448, ng0);
    t2 = (t0 + 25000U);
    t3 = *((char **)t2);
    t2 = (t0 + 31480);
    xsi_vlogvar_wait_assign_value(t2, t3, 0, 0, 8, 1000LL);
    xsi_set_current_line(449, ng0);
    t2 = (t0 + 25320U);
    t3 = *((char **)t2);
    t2 = (t0 + 31800);
    xsi_vlogvar_wait_assign_value(t2, t3, 0, 0, 1, 1000LL);
    xsi_set_current_line(450, ng0);
    t2 = (t0 + 25480U);
    t3 = *((char **)t2);
    t2 = (t0 + 31640);
    xsi_vlogvar_wait_assign_value(t2, t3, 0, 0, 4, 1000LL);
    xsi_set_current_line(451, ng0);
    t2 = (t0 + 25640U);
    t3 = *((char **)t2);
    t2 = (t0 + 31960);
    xsi_vlogvar_wait_assign_value(t2, t3, 0, 0, 1, 1000LL);
    goto LAB2;

}

static void Cont_678_3(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;

LAB0:    t1 = (t0 + 34104U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(678, ng0);
    t2 = (t0 + 26280U);
    t3 = *((char **)t2);
    t2 = (t0 + 35576);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    xsi_vlog_bit_copy(t7, 0, t3, 0, 256);
    xsi_driver_vfirst_trans(t2, 0, 255);
    t8 = (t0 + 35464);
    *((int *)t8) = 1;

LAB1:    return;
}

static void Cont_679_4(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;

LAB0:    t1 = (t0 + 34352U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(679, ng0);
    t2 = (t0 + 26920U);
    t3 = *((char **)t2);
    t2 = (t0 + 35640);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    xsi_vlog_bit_copy(t7, 0, t3, 0, 256);
    xsi_driver_vfirst_trans(t2, 0, 255);
    t8 = (t0 + 35480);
    *((int *)t8) = 1;

LAB1:    return;
}

static void Cont_680_5(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;

LAB0:    t1 = (t0 + 34600U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(680, ng0);
    t2 = (t0 + 27080U);
    t3 = *((char **)t2);
    t2 = (t0 + 35704);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    memcpy(t7, t3, 8);
    xsi_driver_vfirst_trans(t2, 0, 31);
    t8 = (t0 + 35496);
    *((int *)t8) = 1;

LAB1:    return;
}

static void Cont_681_6(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    unsigned int t8;
    unsigned int t9;
    char *t10;
    unsigned int t11;
    unsigned int t12;
    char *t13;
    unsigned int t14;
    unsigned int t15;

LAB0:    t1 = (t0 + 34848U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(681, ng0);
    t2 = ((char*)((ng3)));
    t3 = (t0 + 35768);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    memset(t7, 0, 8);
    t8 = 15U;
    t9 = t8;
    t10 = (t2 + 4);
    t11 = *((unsigned int *)t2);
    t8 = (t8 & t11);
    t12 = *((unsigned int *)t10);
    t9 = (t9 & t12);
    t13 = (t7 + 4);
    t14 = *((unsigned int *)t7);
    *((unsigned int *)t7) = (t14 | t8);
    t15 = *((unsigned int *)t13);
    *((unsigned int *)t13) = (t15 | t9);
    xsi_driver_vfirst_trans(t3, 0, 3);

LAB1:    return;
}

static void Cont_682_7(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    unsigned int t8;
    unsigned int t9;
    char *t10;
    unsigned int t11;
    unsigned int t12;
    char *t13;
    unsigned int t14;
    unsigned int t15;

LAB0:    t1 = (t0 + 35096U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(682, ng0);
    t2 = ((char*)((ng3)));
    t3 = (t0 + 35832);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    memset(t7, 0, 8);
    t8 = 15U;
    t9 = t8;
    t10 = (t2 + 4);
    t11 = *((unsigned int *)t2);
    t8 = (t8 & t11);
    t12 = *((unsigned int *)t10);
    t9 = (t9 & t12);
    t13 = (t7 + 4);
    t14 = *((unsigned int *)t7);
    *((unsigned int *)t7) = (t14 | t8);
    t15 = *((unsigned int *)t13);
    *((unsigned int *)t13) = (t15 | t9);
    xsi_driver_vfirst_trans(t3, 0, 3);

LAB1:    return;
}


extern void work_m_00000000003730238393_1285530785_init()
{
	static char *pe[] = {(void *)Always_315_0,(void *)Always_319_1,(void *)Always_428_2,(void *)Cont_678_3,(void *)Cont_679_4,(void *)Cont_680_5,(void *)Cont_681_6,(void *)Cont_682_7};
	static char *se[] = {(void *)sp_cdiv};
	xsi_register_didat("work_m_00000000003730238393_1285530785", "isim/isim_test.exe.sim/work/m_00000000003730238393_1285530785.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}
