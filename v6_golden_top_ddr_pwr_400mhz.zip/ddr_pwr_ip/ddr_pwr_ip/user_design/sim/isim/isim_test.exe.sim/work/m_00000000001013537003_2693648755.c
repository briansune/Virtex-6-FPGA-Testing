/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "I:/Xilinx_V6_xc6vlx365t/v6_golden_top_ddr_pwr_400mhz/v6_golden_top_ddr_pwr/ddr_pwr_ip/ddr_pwr_ip/user_design/rtl/phy/rd_bitslip.v";
static unsigned int ng1[] = {0U, 0U};
static unsigned int ng2[] = {1U, 0U};
static unsigned int ng3[] = {2U, 0U};
static unsigned int ng4[] = {3U, 0U};



static void Always_100_0(char *t0)
{
    char t6[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    char *t14;

LAB0:    t1 = (t0 + 3784U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(100, ng0);
    t2 = (t0 + 4848);
    *((int *)t2) = 1;
    t3 = (t0 + 3816);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(101, ng0);
    t4 = (t0 + 1664U);
    t5 = *((char **)t4);
    memset(t6, 0, 8);
    t4 = (t6 + 4);
    t7 = (t5 + 4);
    t8 = *((unsigned int *)t5);
    t9 = (t8 >> 2);
    t10 = (t9 & 1);
    *((unsigned int *)t6) = t10;
    t11 = *((unsigned int *)t7);
    t12 = (t11 >> 2);
    t13 = (t12 & 1);
    *((unsigned int *)t4) = t13;
    t14 = (t0 + 2224);
    xsi_vlogvar_wait_assign_value(t14, t6, 0, 0, 1, 1000LL);
    goto LAB2;

}

static void Always_108_1(char *t0)
{
    char t7[8];
    char t10[8];
    char t20[8];
    char t30[8];
    char t40[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    int t6;
    char *t8;
    char *t9;
    char *t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    char *t18;
    char *t19;
    char *t21;
    unsigned int t22;
    unsigned int t23;
    unsigned int t24;
    unsigned int t25;
    unsigned int t26;
    unsigned int t27;
    char *t28;
    char *t29;
    char *t31;
    unsigned int t32;
    unsigned int t33;
    unsigned int t34;
    unsigned int t35;
    unsigned int t36;
    unsigned int t37;
    char *t38;
    char *t39;
    char *t41;
    unsigned int t42;
    unsigned int t43;
    unsigned int t44;
    unsigned int t45;
    unsigned int t46;
    unsigned int t47;
    char *t48;

LAB0:    t1 = (t0 + 4032U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(108, ng0);
    t2 = (t0 + 4864);
    *((int *)t2) = 1;
    t3 = (t0 + 4064);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(109, ng0);
    t4 = (t0 + 1344U);
    t5 = *((char **)t4);

LAB5:    t4 = ((char*)((ng1)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 2, t4, 2);
    if (t6 == 1)
        goto LAB6;

LAB7:    t2 = ((char*)((ng2)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 2, t2, 2);
    if (t6 == 1)
        goto LAB8;

LAB9:    t2 = ((char*)((ng3)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 2, t2, 2);
    if (t6 == 1)
        goto LAB10;

LAB11:    t2 = ((char*)((ng4)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 2, t2, 2);
    if (t6 == 1)
        goto LAB12;

LAB13:
LAB14:    goto LAB2;

LAB6:    xsi_set_current_line(111, ng0);
    t8 = (t0 + 1664U);
    t9 = *((char **)t8);
    memset(t10, 0, 8);
    t8 = (t10 + 4);
    t11 = (t9 + 4);
    t12 = *((unsigned int *)t9);
    t13 = (t12 >> 0);
    t14 = (t13 & 1);
    *((unsigned int *)t10) = t14;
    t15 = *((unsigned int *)t11);
    t16 = (t15 >> 0);
    t17 = (t16 & 1);
    *((unsigned int *)t8) = t17;
    t18 = (t0 + 1664U);
    t19 = *((char **)t18);
    memset(t20, 0, 8);
    t18 = (t20 + 4);
    t21 = (t19 + 4);
    t22 = *((unsigned int *)t19);
    t23 = (t22 >> 1);
    t24 = (t23 & 1);
    *((unsigned int *)t20) = t24;
    t25 = *((unsigned int *)t21);
    t26 = (t25 >> 1);
    t27 = (t26 & 1);
    *((unsigned int *)t18) = t27;
    t28 = (t0 + 1664U);
    t29 = *((char **)t28);
    memset(t30, 0, 8);
    t28 = (t30 + 4);
    t31 = (t29 + 4);
    t32 = *((unsigned int *)t29);
    t33 = (t32 >> 2);
    t34 = (t33 & 1);
    *((unsigned int *)t30) = t34;
    t35 = *((unsigned int *)t31);
    t36 = (t35 >> 2);
    t37 = (t36 & 1);
    *((unsigned int *)t28) = t37;
    t38 = (t0 + 1664U);
    t39 = *((char **)t38);
    memset(t40, 0, 8);
    t38 = (t40 + 4);
    t41 = (t39 + 4);
    t42 = *((unsigned int *)t39);
    t43 = (t42 >> 3);
    t44 = (t43 & 1);
    *((unsigned int *)t40) = t44;
    t45 = *((unsigned int *)t41);
    t46 = (t45 >> 3);
    t47 = (t46 & 1);
    *((unsigned int *)t38) = t47;
    xsi_vlogtype_concat(t7, 4, 4, 4U, t40, 1, t30, 1, t20, 1, t10, 1);
    t48 = (t0 + 2384);
    xsi_vlogvar_assign_value(t48, t7, 0, 0, 4);
    goto LAB14;

LAB8:    xsi_set_current_line(113, ng0);
    t3 = (t0 + 1664U);
    t4 = *((char **)t3);
    memset(t10, 0, 8);
    t3 = (t10 + 4);
    t8 = (t4 + 4);
    t12 = *((unsigned int *)t4);
    t13 = (t12 >> 1);
    t14 = (t13 & 1);
    *((unsigned int *)t10) = t14;
    t15 = *((unsigned int *)t8);
    t16 = (t15 >> 1);
    t17 = (t16 & 1);
    *((unsigned int *)t3) = t17;
    t9 = (t0 + 1664U);
    t11 = *((char **)t9);
    memset(t20, 0, 8);
    t9 = (t20 + 4);
    t18 = (t11 + 4);
    t22 = *((unsigned int *)t11);
    t23 = (t22 >> 2);
    t24 = (t23 & 1);
    *((unsigned int *)t20) = t24;
    t25 = *((unsigned int *)t18);
    t26 = (t25 >> 2);
    t27 = (t26 & 1);
    *((unsigned int *)t9) = t27;
    t19 = (t0 + 1664U);
    t21 = *((char **)t19);
    memset(t30, 0, 8);
    t19 = (t30 + 4);
    t28 = (t21 + 4);
    t32 = *((unsigned int *)t21);
    t33 = (t32 >> 3);
    t34 = (t33 & 1);
    *((unsigned int *)t30) = t34;
    t35 = *((unsigned int *)t28);
    t36 = (t35 >> 3);
    t37 = (t36 & 1);
    *((unsigned int *)t19) = t37;
    t29 = (t0 + 1664U);
    t31 = *((char **)t29);
    memset(t40, 0, 8);
    t29 = (t40 + 4);
    t38 = (t31 + 4);
    t42 = *((unsigned int *)t31);
    t43 = (t42 >> 4);
    t44 = (t43 & 1);
    *((unsigned int *)t40) = t44;
    t45 = *((unsigned int *)t38);
    t46 = (t45 >> 4);
    t47 = (t46 & 1);
    *((unsigned int *)t29) = t47;
    xsi_vlogtype_concat(t7, 4, 4, 4U, t40, 1, t30, 1, t20, 1, t10, 1);
    t39 = (t0 + 2384);
    xsi_vlogvar_assign_value(t39, t7, 0, 0, 4);
    goto LAB14;

LAB10:    xsi_set_current_line(115, ng0);
    t3 = (t0 + 1664U);
    t4 = *((char **)t3);
    memset(t10, 0, 8);
    t3 = (t10 + 4);
    t8 = (t4 + 4);
    t12 = *((unsigned int *)t4);
    t13 = (t12 >> 2);
    t14 = (t13 & 1);
    *((unsigned int *)t10) = t14;
    t15 = *((unsigned int *)t8);
    t16 = (t15 >> 2);
    t17 = (t16 & 1);
    *((unsigned int *)t3) = t17;
    t9 = (t0 + 1664U);
    t11 = *((char **)t9);
    memset(t20, 0, 8);
    t9 = (t20 + 4);
    t18 = (t11 + 4);
    t22 = *((unsigned int *)t11);
    t23 = (t22 >> 3);
    t24 = (t23 & 1);
    *((unsigned int *)t20) = t24;
    t25 = *((unsigned int *)t18);
    t26 = (t25 >> 3);
    t27 = (t26 & 1);
    *((unsigned int *)t9) = t27;
    t19 = (t0 + 1664U);
    t21 = *((char **)t19);
    memset(t30, 0, 8);
    t19 = (t30 + 4);
    t28 = (t21 + 4);
    t32 = *((unsigned int *)t21);
    t33 = (t32 >> 4);
    t34 = (t33 & 1);
    *((unsigned int *)t30) = t34;
    t35 = *((unsigned int *)t28);
    t36 = (t35 >> 4);
    t37 = (t36 & 1);
    *((unsigned int *)t19) = t37;
    t29 = (t0 + 1664U);
    t31 = *((char **)t29);
    memset(t40, 0, 8);
    t29 = (t40 + 4);
    t38 = (t31 + 4);
    t42 = *((unsigned int *)t31);
    t43 = (t42 >> 5);
    t44 = (t43 & 1);
    *((unsigned int *)t40) = t44;
    t45 = *((unsigned int *)t38);
    t46 = (t45 >> 5);
    t47 = (t46 & 1);
    *((unsigned int *)t29) = t47;
    xsi_vlogtype_concat(t7, 4, 4, 4U, t40, 1, t30, 1, t20, 1, t10, 1);
    t39 = (t0 + 2384);
    xsi_vlogvar_assign_value(t39, t7, 0, 0, 4);
    goto LAB14;

LAB12:    xsi_set_current_line(117, ng0);
    t3 = (t0 + 1664U);
    t4 = *((char **)t3);
    memset(t10, 0, 8);
    t3 = (t10 + 4);
    t8 = (t4 + 4);
    t12 = *((unsigned int *)t4);
    t13 = (t12 >> 3);
    t14 = (t13 & 1);
    *((unsigned int *)t10) = t14;
    t15 = *((unsigned int *)t8);
    t16 = (t15 >> 3);
    t17 = (t16 & 1);
    *((unsigned int *)t3) = t17;
    t9 = (t0 + 1664U);
    t11 = *((char **)t9);
    memset(t20, 0, 8);
    t9 = (t20 + 4);
    t18 = (t11 + 4);
    t22 = *((unsigned int *)t11);
    t23 = (t22 >> 4);
    t24 = (t23 & 1);
    *((unsigned int *)t20) = t24;
    t25 = *((unsigned int *)t18);
    t26 = (t25 >> 4);
    t27 = (t26 & 1);
    *((unsigned int *)t9) = t27;
    t19 = (t0 + 1664U);
    t21 = *((char **)t19);
    memset(t30, 0, 8);
    t19 = (t30 + 4);
    t28 = (t21 + 4);
    t32 = *((unsigned int *)t21);
    t33 = (t32 >> 5);
    t34 = (t33 & 1);
    *((unsigned int *)t30) = t34;
    t35 = *((unsigned int *)t28);
    t36 = (t35 >> 5);
    t37 = (t36 & 1);
    *((unsigned int *)t19) = t37;
    t29 = (t0 + 2224);
    t31 = (t29 + 56U);
    t38 = *((char **)t31);
    xsi_vlogtype_concat(t7, 4, 4, 4U, t38, 1, t30, 1, t20, 1, t10, 1);
    t39 = (t0 + 2384);
    xsi_vlogvar_assign_value(t39, t7, 0, 0, 4);
    goto LAB14;

}

static void Always_126_2(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;

LAB0:    t1 = (t0 + 4280U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(126, ng0);
    t2 = (t0 + 4880);
    *((int *)t2) = 1;
    t3 = (t0 + 4312);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(126, ng0);

LAB5:    xsi_set_current_line(127, ng0);
    t4 = (t0 + 2384);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t7 = (t0 + 2544);
    xsi_vlogvar_wait_assign_value(t7, t6, 0, 0, 4, 1000LL);
    xsi_set_current_line(128, ng0);
    t2 = (t0 + 2544);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 2704);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 4, 1000LL);
    xsi_set_current_line(129, ng0);
    t2 = (t0 + 2704);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 2864);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 4, 1000LL);
    goto LAB2;

}

static void Always_132_3(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    int t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;

LAB0:    t1 = (t0 + 4528U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(132, ng0);
    t2 = (t0 + 4896);
    *((int *)t2) = 1;
    t3 = (t0 + 4560);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(133, ng0);
    t4 = (t0 + 1504U);
    t5 = *((char **)t4);

LAB5:    t4 = ((char*)((ng1)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 2, t4, 2);
    if (t6 == 1)
        goto LAB6;

LAB7:    t2 = ((char*)((ng2)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 2, t2, 2);
    if (t6 == 1)
        goto LAB8;

LAB9:    t2 = ((char*)((ng3)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 2, t2, 2);
    if (t6 == 1)
        goto LAB10;

LAB11:    t2 = ((char*)((ng4)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 2, t2, 2);
    if (t6 == 1)
        goto LAB12;

LAB13:
LAB14:    goto LAB2;

LAB6:    xsi_set_current_line(134, ng0);
    t7 = (t0 + 2384);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    t10 = (t0 + 2064);
    xsi_vlogvar_wait_assign_value(t10, t9, 0, 0, 4, 1000LL);
    goto LAB14;

LAB8:    xsi_set_current_line(135, ng0);
    t3 = (t0 + 2544);
    t4 = (t3 + 56U);
    t7 = *((char **)t4);
    t8 = (t0 + 2064);
    xsi_vlogvar_wait_assign_value(t8, t7, 0, 0, 4, 1000LL);
    goto LAB14;

LAB10:    xsi_set_current_line(136, ng0);
    t3 = (t0 + 2704);
    t4 = (t3 + 56U);
    t7 = *((char **)t4);
    t8 = (t0 + 2064);
    xsi_vlogvar_wait_assign_value(t8, t7, 0, 0, 4, 1000LL);
    goto LAB14;

LAB12:    xsi_set_current_line(137, ng0);
    t3 = (t0 + 2864);
    t4 = (t3 + 56U);
    t7 = *((char **)t4);
    t8 = (t0 + 2064);
    xsi_vlogvar_wait_assign_value(t8, t7, 0, 0, 4, 1000LL);
    goto LAB14;

}


extern void work_m_00000000001013537003_2693648755_init()
{
	static char *pe[] = {(void *)Always_100_0,(void *)Always_108_1,(void *)Always_126_2,(void *)Always_132_3};
	xsi_register_didat("work_m_00000000001013537003_2693648755", "isim/isim_test.exe.sim/work/m_00000000001013537003_2693648755.didat");
	xsi_register_executes(pe);
}
