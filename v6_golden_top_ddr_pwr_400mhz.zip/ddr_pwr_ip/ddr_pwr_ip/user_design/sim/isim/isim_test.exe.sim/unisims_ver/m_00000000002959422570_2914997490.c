/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static unsigned int ng0[] = {3U, 0U};
static unsigned int ng1[] = {1U, 0U};
static unsigned int ng2[] = {0U, 0U};
static unsigned int ng3[] = {16U, 0U};
static unsigned int ng4[] = {16U, 16U};
static unsigned int ng5[] = {4U, 0U};
static unsigned int ng6[] = {20U, 0U};
static unsigned int ng7[] = {20U, 16U};
static unsigned int ng8[] = {9U, 0U};
static unsigned int ng9[] = {25U, 0U};
static unsigned int ng10[] = {10U, 0U};
static unsigned int ng11[] = {26U, 0U};
static unsigned int ng12[] = {8U, 0U};
static unsigned int ng13[] = {24U, 0U};
static unsigned int ng14[] = {24U, 16U};
static const char *ng15 = "DATA_RATE_TQ %b and/or TRISTATE_WIDTH %b at time %t are not supported by OSERDES";
static unsigned int ng16[] = {4U, 4U};
static unsigned int ng17[] = {20U, 4U};
static unsigned int ng18[] = {20U, 20U};
static unsigned int ng19[] = {25U, 16U};

static void NetReassign_1357_10(char *);
static void NetReassign_1358_11(char *);
static void NetReassign_1359_12(char *);
static void NetReassign_1360_13(char *);


static void Cont_1313_0(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    unsigned int t8;
    unsigned int t9;
    char *t10;
    unsigned int t11;
    unsigned int t12;
    char *t13;
    unsigned int t14;
    unsigned int t15;

LAB0:    t1 = (t0 + 7600U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    t2 = ((char*)((ng0)));
    t3 = (t0 + 11384);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    memset(t7, 0, 8);
    t8 = 3U;
    t9 = t8;
    t10 = (t2 + 4);
    t11 = *((unsigned int *)t2);
    t8 = (t8 & t11);
    t12 = *((unsigned int *)t10);
    t9 = (t9 & t12);
    t13 = (t7 + 4);
    t14 = *((unsigned int *)t7);
    *((unsigned int *)t7) = (t14 | t8);
    t15 = *((unsigned int *)t13);
    *((unsigned int *)t13) = (t15 | t9);
    xsi_driver_vfirst_trans(t3, 0, 1);

LAB1:    return;
}

static void Cont_1314_1(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    unsigned int t8;
    unsigned int t9;
    char *t10;
    unsigned int t11;
    unsigned int t12;
    char *t13;
    unsigned int t14;
    unsigned int t15;

LAB0:    t1 = (t0 + 7848U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    t2 = ((char*)((ng1)));
    t3 = (t0 + 11448);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    memset(t7, 0, 8);
    t8 = 1U;
    t9 = t8;
    t10 = (t2 + 4);
    t11 = *((unsigned int *)t2);
    t8 = (t8 & t11);
    t12 = *((unsigned int *)t10);
    t9 = (t9 & t12);
    t13 = (t7 + 4);
    t14 = *((unsigned int *)t7);
    *((unsigned int *)t7) = (t14 | t8);
    t15 = *((unsigned int *)t13);
    *((unsigned int *)t13) = (t15 | t9);
    xsi_driver_vfirst_trans(t3, 0, 0);

LAB1:    return;
}

static void Cont_1315_2(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    unsigned int t8;
    unsigned int t9;
    char *t10;
    unsigned int t11;
    unsigned int t12;
    char *t13;
    unsigned int t14;
    unsigned int t15;

LAB0:    t1 = (t0 + 8096U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    t2 = ((char*)((ng2)));
    t3 = (t0 + 11512);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    memset(t7, 0, 8);
    t8 = 15U;
    t9 = t8;
    t10 = (t2 + 4);
    t11 = *((unsigned int *)t2);
    t8 = (t8 & t11);
    t12 = *((unsigned int *)t10);
    t9 = (t9 & t12);
    t13 = (t7 + 4);
    t14 = *((unsigned int *)t7);
    *((unsigned int *)t7) = (t14 | t8);
    t15 = *((unsigned int *)t13);
    *((unsigned int *)t13) = (t15 | t9);
    xsi_driver_vfirst_trans(t3, 0, 3);

LAB1:    return;
}

static void Cont_1333_3(char *t0)
{
    char t3[8];
    char *t1;
    char *t2;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    unsigned int t11;
    unsigned int t12;
    char *t13;
    unsigned int t14;
    unsigned int t15;
    char *t16;
    unsigned int t17;
    unsigned int t18;
    char *t19;

LAB0:    t1 = (t0 + 8344U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    t2 = (t0 + 2760U);
    t4 = *((char **)t2);
    t2 = (t0 + 2920U);
    t5 = *((char **)t2);
    t2 = (t0 + 1960U);
    t6 = *((char **)t2);
    xsi_vlogtype_concat(t3, 5, 5, 3U, t6, 1, t5, 2, t4, 2);
    t2 = (t0 + 11576);
    t7 = (t2 + 56U);
    t8 = *((char **)t7);
    t9 = (t8 + 56U);
    t10 = *((char **)t9);
    memset(t10, 0, 8);
    t11 = 31U;
    t12 = t11;
    t13 = (t3 + 4);
    t14 = *((unsigned int *)t3);
    t11 = (t11 & t14);
    t15 = *((unsigned int *)t13);
    t12 = (t12 & t15);
    t16 = (t10 + 4);
    t17 = *((unsigned int *)t10);
    *((unsigned int *)t10) = (t17 | t11);
    t18 = *((unsigned int *)t16);
    *((unsigned int *)t16) = (t18 | t12);
    xsi_driver_vfirst_trans(t2, 0, 4);
    t19 = (t0 + 11144);
    *((int *)t19) = 1;

LAB1:    return;
}

static void NetDecl_1351_4(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    unsigned int t10;
    unsigned int t11;
    char *t12;
    unsigned int t13;
    unsigned int t14;
    char *t15;
    unsigned int t16;
    unsigned int t17;
    char *t18;

LAB0:    t1 = (t0 + 8592U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    t2 = (t0 + 13864);
    t3 = *((char **)t2);
    t4 = ((((char*)(t3))) + 40U);
    t5 = *((char **)t4);
    t4 = (t0 + 11640);
    t6 = (t4 + 56U);
    t7 = *((char **)t6);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    memset(t9, 0, 8);
    t10 = 1U;
    t11 = t10;
    t12 = (t5 + 4);
    t13 = *((unsigned int *)t5);
    t10 = (t10 & t13);
    t14 = *((unsigned int *)t12);
    t11 = (t11 & t14);
    t15 = (t9 + 4);
    t16 = *((unsigned int *)t9);
    *((unsigned int *)t9) = (t16 | t10);
    t17 = *((unsigned int *)t15);
    *((unsigned int *)t15) = (t17 | t11);
    xsi_driver_vfirst_trans(t4, 0, 0U);
    t18 = (t0 + 11160);
    *((int *)t18) = 1;

LAB1:    return;
}

static void Always_1353_5(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    unsigned int t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    char *t11;
    char *t12;

LAB0:    t1 = (t0 + 8840U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    t2 = (t0 + 11176);
    *((int *)t2) = 1;
    t3 = (t0 + 8872);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:
LAB5:    t4 = (t0 + 4520U);
    t5 = *((char **)t4);
    t4 = (t5 + 4);
    t6 = *((unsigned int *)t4);
    t7 = (~(t6));
    t8 = *((unsigned int *)t5);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB6;

LAB7:
LAB10:    t2 = (t0 + 5240);
    xsi_vlogvar_deassign(t2, 0, 0);
    t2 = (t0 + 5400);
    xsi_vlogvar_deassign(t2, 0, 0);
    t2 = (t0 + 5560);
    xsi_vlogvar_deassign(t2, 0, 0);
    t2 = (t0 + 5720);
    xsi_vlogvar_deassign(t2, 0, 0);

LAB8:    goto LAB2;

LAB6:
LAB9:    t11 = (t0 + 5240);
    xsi_set_assignedflag(t11);
    t12 = (t0 + 13872);
    *((int *)t12) = 1;
    NetReassign_1357_10(t0);
    t2 = (t0 + 5400);
    xsi_set_assignedflag(t2);
    t3 = (t0 + 13876);
    *((int *)t3) = 1;
    NetReassign_1358_11(t0);
    t2 = (t0 + 5560);
    xsi_set_assignedflag(t2);
    t3 = (t0 + 13880);
    *((int *)t3) = 1;
    NetReassign_1359_12(t0);
    t2 = (t0 + 5720);
    xsi_set_assignedflag(t2);
    t3 = (t0 + 13884);
    *((int *)t3) = 1;
    NetReassign_1360_13(t0);
    goto LAB8;

}

static void Always_1377_6(char *t0)
{
    char t6[8];
    char t8[8];
    char t23[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t7;
    char *t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    char *t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    unsigned int t21;
    char *t22;
    unsigned int t24;
    unsigned int t25;
    unsigned int t26;
    char *t27;
    char *t28;
    char *t29;
    unsigned int t30;
    unsigned int t31;
    unsigned int t32;
    unsigned int t33;
    unsigned int t34;
    unsigned int t35;
    unsigned int t36;
    char *t37;
    char *t38;
    unsigned int t39;
    unsigned int t40;
    unsigned int t41;
    unsigned int t42;
    unsigned int t43;
    unsigned int t44;
    unsigned int t45;
    unsigned int t46;
    int t47;
    int t48;
    unsigned int t49;
    unsigned int t50;
    unsigned int t51;
    unsigned int t52;
    unsigned int t53;
    unsigned int t54;
    char *t55;
    unsigned int t56;
    unsigned int t57;
    unsigned int t58;
    unsigned int t59;
    unsigned int t60;
    char *t61;
    char *t62;

LAB0:    t1 = (t0 + 9088U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    t2 = (t0 + 11192);
    *((int *)t2) = 1;
    t3 = (t0 + 9120);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:
LAB5:
LAB6:    t4 = (t0 + 2440U);
    t5 = *((char **)t4);
    t4 = (t0 + 3720U);
    t7 = *((char **)t4);
    memset(t8, 0, 8);
    t4 = (t8 + 4);
    t9 = (t7 + 4);
    t10 = *((unsigned int *)t7);
    t11 = (t10 >> 1);
    t12 = (t11 & 1);
    *((unsigned int *)t8) = t12;
    t13 = *((unsigned int *)t9);
    t14 = (t13 >> 1);
    t15 = (t14 & 1);
    *((unsigned int *)t4) = t15;
    memset(t6, 0, 8);
    t16 = (t8 + 4);
    t17 = *((unsigned int *)t16);
    t18 = (~(t17));
    t19 = *((unsigned int *)t8);
    t20 = (t19 & t18);
    t21 = (t20 & 1U);
    if (t21 != 0)
        goto LAB10;

LAB8:    if (*((unsigned int *)t16) == 0)
        goto LAB7;

LAB9:    t22 = (t6 + 4);
    *((unsigned int *)t6) = 1;
    *((unsigned int *)t22) = 1;

LAB10:    t24 = *((unsigned int *)t5);
    t25 = *((unsigned int *)t6);
    t26 = (t24 & t25);
    *((unsigned int *)t23) = t26;
    t27 = (t5 + 4);
    t28 = (t6 + 4);
    t29 = (t23 + 4);
    t30 = *((unsigned int *)t27);
    t31 = *((unsigned int *)t28);
    t32 = (t30 | t31);
    *((unsigned int *)t29) = t32;
    t33 = *((unsigned int *)t29);
    t34 = (t33 != 0);
    if (t34 == 1)
        goto LAB11;

LAB12:
LAB13:    t55 = (t23 + 4);
    t56 = *((unsigned int *)t55);
    t57 = (~(t56));
    t58 = *((unsigned int *)t23);
    t59 = (t58 & t57);
    t60 = (t59 != 0);
    if (t60 > 0)
        goto LAB14;

LAB15:    t2 = (t0 + 3720U);
    t3 = *((char **)t2);
    memset(t8, 0, 8);
    t2 = (t8 + 4);
    t4 = (t3 + 4);
    t10 = *((unsigned int *)t3);
    t11 = (t10 >> 1);
    t12 = (t11 & 1);
    *((unsigned int *)t8) = t12;
    t13 = *((unsigned int *)t4);
    t14 = (t13 >> 1);
    t15 = (t14 & 1);
    *((unsigned int *)t2) = t15;
    memset(t6, 0, 8);
    t5 = (t8 + 4);
    t17 = *((unsigned int *)t5);
    t18 = (~(t17));
    t19 = *((unsigned int *)t8);
    t20 = (t19 & t18);
    t21 = (t20 & 1U);
    if (t21 != 0)
        goto LAB21;

LAB19:    if (*((unsigned int *)t5) == 0)
        goto LAB18;

LAB20:    t7 = (t6 + 4);
    *((unsigned int *)t6) = 1;
    *((unsigned int *)t7) = 1;

LAB21:    t9 = (t6 + 4);
    t24 = *((unsigned int *)t9);
    t25 = (~(t24));
    t26 = *((unsigned int *)t6);
    t30 = (t26 & t25);
    t31 = (t30 != 0);
    if (t31 > 0)
        goto LAB22;

LAB23:
LAB24:
LAB16:    goto LAB2;

LAB7:    *((unsigned int *)t6) = 1;
    goto LAB10;

LAB11:    t35 = *((unsigned int *)t23);
    t36 = *((unsigned int *)t29);
    *((unsigned int *)t23) = (t35 | t36);
    t37 = (t5 + 4);
    t38 = (t6 + 4);
    t39 = *((unsigned int *)t5);
    t40 = (~(t39));
    t41 = *((unsigned int *)t37);
    t42 = (~(t41));
    t43 = *((unsigned int *)t6);
    t44 = (~(t43));
    t45 = *((unsigned int *)t38);
    t46 = (~(t45));
    t47 = (t40 & t42);
    t48 = (t44 & t46);
    t49 = (~(t47));
    t50 = (~(t48));
    t51 = *((unsigned int *)t29);
    *((unsigned int *)t29) = (t51 & t49);
    t52 = *((unsigned int *)t29);
    *((unsigned int *)t29) = (t52 & t50);
    t53 = *((unsigned int *)t23);
    *((unsigned int *)t23) = (t53 & t49);
    t54 = *((unsigned int *)t23);
    *((unsigned int *)t23) = (t54 & t50);
    goto LAB13;

LAB14:
LAB17:    t61 = ((char*)((ng2)));
    t62 = (t0 + 5240);
    xsi_vlogvar_wait_assign_value(t62, t61, 0, 0, 1, 10LL);
    t2 = ((char*)((ng2)));
    t3 = (t0 + 5400);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 1, 10LL);
    t2 = ((char*)((ng2)));
    t3 = (t0 + 5560);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 1, 10LL);
    t2 = ((char*)((ng2)));
    t3 = (t0 + 5720);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 1, 10LL);
    goto LAB16;

LAB18:    *((unsigned int *)t6) = 1;
    goto LAB21;

LAB22:
LAB25:    t16 = (t0 + 1320U);
    t22 = *((char **)t16);
    t16 = (t0 + 5240);
    xsi_vlogvar_wait_assign_value(t16, t22, 0, 0, 1, 10LL);
    t2 = (t0 + 1480U);
    t3 = *((char **)t2);
    t2 = (t0 + 5400);
    xsi_vlogvar_wait_assign_value(t2, t3, 0, 0, 1, 10LL);
    t2 = (t0 + 1640U);
    t3 = *((char **)t2);
    t2 = (t0 + 5560);
    xsi_vlogvar_wait_assign_value(t2, t3, 0, 0, 1, 10LL);
    t2 = (t0 + 1800U);
    t3 = *((char **)t2);
    t2 = (t0 + 5720);
    xsi_vlogvar_wait_assign_value(t2, t3, 0, 0, 1, 10LL);
    goto LAB24;

}

static void Always_1398_7(char *t0)
{
    char t7[8];
    char t15[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    char *t19;
    char *t20;
    char *t21;
    unsigned int t22;
    unsigned int t23;
    unsigned int t24;
    unsigned int t25;
    unsigned int t26;
    unsigned int t27;
    unsigned int t28;
    char *t29;
    char *t30;
    unsigned int t31;
    unsigned int t32;
    unsigned int t33;
    unsigned int t34;
    unsigned int t35;
    unsigned int t36;
    unsigned int t37;
    unsigned int t38;
    int t39;
    int t40;
    unsigned int t41;
    unsigned int t42;
    unsigned int t43;
    unsigned int t44;
    unsigned int t45;
    unsigned int t46;
    char *t47;
    unsigned int t48;
    unsigned int t49;
    unsigned int t50;
    unsigned int t51;
    unsigned int t52;
    char *t53;
    char *t54;

LAB0:    t1 = (t0 + 9336U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    t2 = (t0 + 11208);
    *((int *)t2) = 1;
    t3 = (t0 + 9368);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:
LAB5:
LAB6:    t4 = (t0 + 2440U);
    t5 = *((char **)t4);
    t4 = (t0 + 3720U);
    t6 = *((char **)t4);
    memset(t7, 0, 8);
    t4 = (t7 + 4);
    t8 = (t6 + 4);
    t9 = *((unsigned int *)t6);
    t10 = (t9 >> 1);
    t11 = (t10 & 1);
    *((unsigned int *)t7) = t11;
    t12 = *((unsigned int *)t8);
    t13 = (t12 >> 1);
    t14 = (t13 & 1);
    *((unsigned int *)t4) = t14;
    t16 = *((unsigned int *)t5);
    t17 = *((unsigned int *)t7);
    t18 = (t16 & t17);
    *((unsigned int *)t15) = t18;
    t19 = (t5 + 4);
    t20 = (t7 + 4);
    t21 = (t15 + 4);
    t22 = *((unsigned int *)t19);
    t23 = *((unsigned int *)t20);
    t24 = (t22 | t23);
    *((unsigned int *)t21) = t24;
    t25 = *((unsigned int *)t21);
    t26 = (t25 != 0);
    if (t26 == 1)
        goto LAB7;

LAB8:
LAB9:    t47 = (t15 + 4);
    t48 = *((unsigned int *)t47);
    t49 = (~(t48));
    t50 = *((unsigned int *)t15);
    t51 = (t50 & t49);
    t52 = (t51 != 0);
    if (t52 > 0)
        goto LAB10;

LAB11:    t2 = (t0 + 3720U);
    t3 = *((char **)t2);
    memset(t7, 0, 8);
    t2 = (t7 + 4);
    t4 = (t3 + 4);
    t9 = *((unsigned int *)t3);
    t10 = (t9 >> 1);
    t11 = (t10 & 1);
    *((unsigned int *)t7) = t11;
    t12 = *((unsigned int *)t4);
    t13 = (t12 >> 1);
    t14 = (t13 & 1);
    *((unsigned int *)t2) = t14;
    t5 = (t7 + 4);
    t16 = *((unsigned int *)t5);
    t17 = (~(t16));
    t18 = *((unsigned int *)t7);
    t22 = (t18 & t17);
    t23 = (t22 != 0);
    if (t23 > 0)
        goto LAB14;

LAB15:
LAB16:
LAB12:    goto LAB2;

LAB7:    t27 = *((unsigned int *)t15);
    t28 = *((unsigned int *)t21);
    *((unsigned int *)t15) = (t27 | t28);
    t29 = (t5 + 4);
    t30 = (t7 + 4);
    t31 = *((unsigned int *)t5);
    t32 = (~(t31));
    t33 = *((unsigned int *)t29);
    t34 = (~(t33));
    t35 = *((unsigned int *)t7);
    t36 = (~(t35));
    t37 = *((unsigned int *)t30);
    t38 = (~(t37));
    t39 = (t32 & t34);
    t40 = (t36 & t38);
    t41 = (~(t39));
    t42 = (~(t40));
    t43 = *((unsigned int *)t21);
    *((unsigned int *)t21) = (t43 & t41);
    t44 = *((unsigned int *)t21);
    *((unsigned int *)t21) = (t44 & t42);
    t45 = *((unsigned int *)t15);
    *((unsigned int *)t15) = (t45 & t41);
    t46 = *((unsigned int *)t15);
    *((unsigned int *)t15) = (t46 & t42);
    goto LAB9;

LAB10:
LAB13:    t53 = ((char*)((ng2)));
    t54 = (t0 + 5240);
    xsi_vlogvar_wait_assign_value(t54, t53, 0, 0, 1, 10LL);
    t2 = ((char*)((ng2)));
    t3 = (t0 + 5400);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 1, 10LL);
    t2 = ((char*)((ng2)));
    t3 = (t0 + 5560);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 1, 10LL);
    t2 = ((char*)((ng2)));
    t3 = (t0 + 5720);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 1, 10LL);
    goto LAB12;

LAB14:
LAB17:    t6 = (t0 + 1320U);
    t8 = *((char **)t6);
    t6 = (t0 + 5240);
    xsi_vlogvar_wait_assign_value(t6, t8, 0, 0, 1, 10LL);
    t2 = (t0 + 1480U);
    t3 = *((char **)t2);
    t2 = (t0 + 5400);
    xsi_vlogvar_wait_assign_value(t2, t3, 0, 0, 1, 10LL);
    t2 = (t0 + 1640U);
    t3 = *((char **)t2);
    t2 = (t0 + 5560);
    xsi_vlogvar_wait_assign_value(t2, t3, 0, 0, 1, 10LL);
    t2 = (t0 + 1800U);
    t3 = *((char **)t2);
    t2 = (t0 + 5720);
    xsi_vlogvar_wait_assign_value(t2, t3, 0, 0, 1, 10LL);
    goto LAB16;

}

static void Always_1423_8(char *t0)
{
    char t12[16];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    int t6;
    char *t7;
    char *t8;
    int t9;
    int t10;
    char *t11;

LAB0:    t1 = (t0 + 9584U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    t2 = (t0 + 11224);
    *((int *)t2) = 1;
    t3 = (t0 + 9616);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:
LAB5:    t4 = (t0 + 4360U);
    t5 = *((char **)t4);

LAB6:    t4 = ((char*)((ng2)));
    t6 = xsi_vlog_unsigned_case_xcompare(t5, 5, t4, 5);
    if (t6 == 1)
        goto LAB7;

LAB8:    t2 = ((char*)((ng3)));
    t6 = xsi_vlog_unsigned_case_xcompare(t5, 5, t2, 5);
    if (t6 == 1)
        goto LAB9;

LAB10:    t2 = ((char*)((ng4)));
    t6 = xsi_vlog_unsigned_case_xcompare(t5, 5, t2, 5);
    if (t6 == 1)
        goto LAB11;

LAB12:    t2 = ((char*)((ng5)));
    t6 = xsi_vlog_unsigned_case_xcompare(t5, 5, t2, 5);
    if (t6 == 1)
        goto LAB13;

LAB14:    t2 = ((char*)((ng6)));
    t6 = xsi_vlog_unsigned_case_xcompare(t5, 5, t2, 5);
    if (t6 == 1)
        goto LAB15;

LAB16:    t2 = ((char*)((ng7)));
    t6 = xsi_vlog_unsigned_case_xcompare(t5, 5, t2, 5);
    if (t6 == 1)
        goto LAB17;

LAB18:    t2 = ((char*)((ng8)));
    t6 = xsi_vlog_unsigned_case_xcompare(t5, 5, t2, 5);
    if (t6 == 1)
        goto LAB19;

LAB20:    t2 = ((char*)((ng9)));
    t6 = xsi_vlog_unsigned_case_xcompare(t5, 5, t2, 5);
    if (t6 == 1)
        goto LAB21;

LAB22:    t2 = ((char*)((ng10)));
    t6 = xsi_vlog_unsigned_case_xcompare(t5, 5, t2, 5);
    if (t6 == 1)
        goto LAB23;

LAB24:    t2 = ((char*)((ng11)));
    t6 = xsi_vlog_unsigned_case_xcompare(t5, 5, t2, 5);
    if (t6 == 1)
        goto LAB25;

LAB26:    t2 = ((char*)((ng12)));
    t6 = xsi_vlog_unsigned_case_xcompare(t5, 5, t2, 5);
    if (t6 == 1)
        goto LAB27;

LAB28:    t3 = ((char*)((ng13)));
    t9 = xsi_vlog_unsigned_case_xcompare(t5, 5, t3, 5);
    if (t9 == 1)
        goto LAB29;

LAB30:    t4 = ((char*)((ng14)));
    t10 = xsi_vlog_unsigned_case_xcompare(t5, 5, t4, 5);
    if (t10 == 1)
        goto LAB31;

LAB32:
LAB34:
LAB33:    t7 = (t0 + 2920U);
    t8 = *((char **)t7);
    t7 = (t0 + 2760U);
    t11 = *((char **)t7);
    t7 = xsi_vlog_time(t12, 10.000000000000000, 1.0000000000000000);
    xsi_vlogfile_write(1, 0, 0, ng15, 4, t0, (char)118, t8, 2, (char)118, t11, 2, (char)118, t12, 64);

LAB35:    goto LAB2;

LAB7:    t7 = (t0 + 1320U);
    t8 = *((char **)t7);
    t7 = (t0 + 4920);
    xsi_vlogvar_wait_assign_value(t7, t8, 0, 0, 1, 10LL);
    goto LAB35;

LAB9:    t3 = (t0 + 1320U);
    t4 = *((char **)t3);
    t3 = (t0 + 4920);
    xsi_vlogvar_wait_assign_value(t3, t4, 0, 0, 1, 10LL);
    goto LAB35;

LAB11:    t3 = (t0 + 1320U);
    t4 = *((char **)t3);
    t3 = (t0 + 4920);
    xsi_vlogvar_wait_assign_value(t3, t4, 0, 0, 1, 10LL);
    goto LAB35;

LAB13:    t3 = (t0 + 1320U);
    t4 = *((char **)t3);
    t3 = (t0 + 4920);
    xsi_vlogvar_wait_assign_value(t3, t4, 0, 0, 1, 10LL);
    goto LAB35;

LAB15:    t3 = (t0 + 1320U);
    t4 = *((char **)t3);
    t3 = (t0 + 4920);
    xsi_vlogvar_wait_assign_value(t3, t4, 0, 0, 1, 10LL);
    goto LAB35;

LAB17:    t3 = (t0 + 1320U);
    t4 = *((char **)t3);
    t3 = (t0 + 4920);
    xsi_vlogvar_wait_assign_value(t3, t4, 0, 0, 1, 10LL);
    goto LAB35;

LAB19:    t3 = (t0 + 1320U);
    t4 = *((char **)t3);
    t3 = (t0 + 4920);
    xsi_vlogvar_wait_assign_value(t3, t4, 0, 0, 1, 10LL);
    goto LAB35;

LAB21:    t3 = (t0 + 1320U);
    t4 = *((char **)t3);
    t3 = (t0 + 4920);
    xsi_vlogvar_wait_assign_value(t3, t4, 0, 0, 1, 10LL);
    goto LAB35;

LAB23:    t3 = (t0 + 5560);
    t4 = (t3 + 56U);
    t7 = *((char **)t4);
    t8 = (t0 + 4920);
    xsi_vlogvar_wait_assign_value(t8, t7, 0, 0, 1, 10LL);
    goto LAB35;

LAB25:    t3 = (t0 + 5240);
    t4 = (t3 + 56U);
    t7 = *((char **)t4);
    t8 = (t0 + 4920);
    xsi_vlogvar_wait_assign_value(t8, t7, 0, 0, 1, 10LL);
    goto LAB35;

LAB27:    goto LAB35;

LAB29:    goto LAB35;

LAB31:    goto LAB35;

}

static void Always_1447_9(char *t0)
{
    char t12[16];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    int t6;
    char *t7;
    char *t8;
    int t9;
    int t10;
    char *t11;

LAB0:    t1 = (t0 + 9832U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    t2 = (t0 + 11240);
    *((int *)t2) = 1;
    t3 = (t0 + 9864);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:
LAB5:    t4 = (t0 + 4360U);
    t5 = *((char **)t4);

LAB6:    t4 = ((char*)((ng2)));
    t6 = xsi_vlog_unsigned_case_xcompare(t5, 5, t4, 5);
    if (t6 == 1)
        goto LAB7;

LAB8:    t2 = ((char*)((ng5)));
    t6 = xsi_vlog_unsigned_case_xcompare(t5, 5, t2, 5);
    if (t6 == 1)
        goto LAB9;

LAB10:    t2 = ((char*)((ng3)));
    t6 = xsi_vlog_unsigned_case_xcompare(t5, 5, t2, 5);
    if (t6 == 1)
        goto LAB11;

LAB12:    t2 = ((char*)((ng6)));
    t6 = xsi_vlog_unsigned_case_xcompare(t5, 5, t2, 5);
    if (t6 == 1)
        goto LAB13;

LAB14:    t2 = ((char*)((ng4)));
    t6 = xsi_vlog_unsigned_case_xcompare(t5, 5, t2, 5);
    if (t6 == 1)
        goto LAB15;

LAB16:    t2 = ((char*)((ng7)));
    t6 = xsi_vlog_unsigned_case_xcompare(t5, 5, t2, 5);
    if (t6 == 1)
        goto LAB17;

LAB18:    t2 = ((char*)((ng16)));
    t6 = xsi_vlog_unsigned_case_xcompare(t5, 5, t2, 5);
    if (t6 == 1)
        goto LAB19;

LAB20:    t2 = ((char*)((ng17)));
    t6 = xsi_vlog_unsigned_case_xcompare(t5, 5, t2, 5);
    if (t6 == 1)
        goto LAB21;

LAB22:    t2 = ((char*)((ng18)));
    t6 = xsi_vlog_unsigned_case_xcompare(t5, 5, t2, 5);
    if (t6 == 1)
        goto LAB23;

LAB24:    t2 = ((char*)((ng8)));
    t6 = xsi_vlog_unsigned_case_xcompare(t5, 5, t2, 5);
    if (t6 == 1)
        goto LAB25;

LAB26:    t2 = ((char*)((ng9)));
    t6 = xsi_vlog_unsigned_case_xcompare(t5, 5, t2, 5);
    if (t6 == 1)
        goto LAB27;

LAB28:    t2 = ((char*)((ng19)));
    t6 = xsi_vlog_unsigned_case_xcompare(t5, 5, t2, 5);
    if (t6 == 1)
        goto LAB29;

LAB30:    t2 = ((char*)((ng10)));
    t6 = xsi_vlog_unsigned_case_xcompare(t5, 5, t2, 5);
    if (t6 == 1)
        goto LAB31;

LAB32:    t2 = ((char*)((ng11)));
    t6 = xsi_vlog_unsigned_case_xcompare(t5, 5, t2, 5);
    if (t6 == 1)
        goto LAB33;

LAB34:    t2 = ((char*)((ng12)));
    t6 = xsi_vlog_unsigned_case_xcompare(t5, 5, t2, 5);
    if (t6 == 1)
        goto LAB35;

LAB36:    t3 = ((char*)((ng13)));
    t9 = xsi_vlog_unsigned_case_xcompare(t5, 5, t3, 5);
    if (t9 == 1)
        goto LAB37;

LAB38:    t4 = ((char*)((ng14)));
    t10 = xsi_vlog_unsigned_case_xcompare(t5, 5, t4, 5);
    if (t10 == 1)
        goto LAB39;

LAB40:
LAB42:
LAB41:    t7 = (t0 + 2920U);
    t8 = *((char **)t7);
    t7 = (t0 + 2760U);
    t11 = *((char **)t7);
    t7 = xsi_vlog_time(t12, 10.000000000000000, 1.0000000000000000);
    xsi_vlogfile_write(1, 0, 0, ng15, 4, t0, (char)118, t8, 2, (char)118, t11, 2, (char)118, t12, 64);

LAB43:    goto LAB2;

LAB7:    t7 = (t0 + 1480U);
    t8 = *((char **)t7);
    t7 = (t0 + 5080);
    xsi_vlogvar_wait_assign_value(t7, t8, 0, 0, 1, 10LL);
    goto LAB43;

LAB9:    t3 = (t0 + 1480U);
    t4 = *((char **)t3);
    t3 = (t0 + 5080);
    xsi_vlogvar_wait_assign_value(t3, t4, 0, 0, 1, 10LL);
    goto LAB43;

LAB11:    t3 = (t0 + 1480U);
    t4 = *((char **)t3);
    t3 = (t0 + 5080);
    xsi_vlogvar_wait_assign_value(t3, t4, 0, 0, 1, 10LL);
    goto LAB43;

LAB13:    t3 = (t0 + 1480U);
    t4 = *((char **)t3);
    t3 = (t0 + 5080);
    xsi_vlogvar_wait_assign_value(t3, t4, 0, 0, 1, 10LL);
    goto LAB43;

LAB15:    t3 = (t0 + 1480U);
    t4 = *((char **)t3);
    t3 = (t0 + 5080);
    xsi_vlogvar_wait_assign_value(t3, t4, 0, 0, 1, 10LL);
    goto LAB43;

LAB17:    t3 = (t0 + 1480U);
    t4 = *((char **)t3);
    t3 = (t0 + 5080);
    xsi_vlogvar_wait_assign_value(t3, t4, 0, 0, 1, 10LL);
    goto LAB43;

LAB19:    t3 = (t0 + 1480U);
    t4 = *((char **)t3);
    t3 = (t0 + 5080);
    xsi_vlogvar_wait_assign_value(t3, t4, 0, 0, 1, 10LL);
    goto LAB43;

LAB21:    t3 = (t0 + 1480U);
    t4 = *((char **)t3);
    t3 = (t0 + 5080);
    xsi_vlogvar_wait_assign_value(t3, t4, 0, 0, 1, 10LL);
    goto LAB43;

LAB23:    t3 = (t0 + 1480U);
    t4 = *((char **)t3);
    t3 = (t0 + 5080);
    xsi_vlogvar_wait_assign_value(t3, t4, 0, 0, 1, 10LL);
    goto LAB43;

LAB25:    t3 = (t0 + 1480U);
    t4 = *((char **)t3);
    t3 = (t0 + 5080);
    xsi_vlogvar_wait_assign_value(t3, t4, 0, 0, 1, 10LL);
    goto LAB43;

LAB27:    t3 = (t0 + 1480U);
    t4 = *((char **)t3);
    t3 = (t0 + 5080);
    xsi_vlogvar_wait_assign_value(t3, t4, 0, 0, 1, 10LL);
    goto LAB43;

LAB29:    t3 = (t0 + 1480U);
    t4 = *((char **)t3);
    t3 = (t0 + 5080);
    xsi_vlogvar_wait_assign_value(t3, t4, 0, 0, 1, 10LL);
    goto LAB43;

LAB31:    t3 = (t0 + 5720);
    t4 = (t3 + 56U);
    t7 = *((char **)t4);
    t8 = (t0 + 5080);
    xsi_vlogvar_wait_assign_value(t8, t7, 0, 0, 1, 10LL);
    goto LAB43;

LAB33:    t3 = (t0 + 5400);
    t4 = (t3 + 56U);
    t7 = *((char **)t4);
    t8 = (t0 + 5080);
    xsi_vlogvar_wait_assign_value(t8, t7, 0, 0, 1, 10LL);
    goto LAB43;

LAB35:    goto LAB43;

LAB37:    goto LAB43;

LAB39:    goto LAB43;

}

static void NetReassign_1357_10(char *t0)
{
    char t5[8];
    char *t1;
    char *t2;
    unsigned int t3;
    char *t4;
    char *t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;

LAB0:    t1 = (t0 + 10080U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    t3 = 0;
    t2 = (t0 + 3560U);
    t4 = *((char **)t2);
    memset(t5, 0, 8);
    t2 = (t5 + 4);
    t6 = (t4 + 4);
    t7 = *((unsigned int *)t4);
    t8 = (t7 >> 0);
    t9 = (t8 & 1);
    *((unsigned int *)t5) = t9;
    t10 = *((unsigned int *)t6);
    t11 = (t10 >> 0);
    t12 = (t11 & 1);
    *((unsigned int *)t2) = t12;
    t13 = (t0 + 13872);
    if (*((int *)t13) > 0)
        goto LAB4;

LAB5:    if (t3 > 0)
        goto LAB6;

LAB7:    t16 = (t0 + 11256);
    *((int *)t16) = 0;

LAB8:
LAB1:    return;
LAB4:    t14 = (t0 + 5240);
    xsi_vlogvar_assignassignvalue(t14, t5, 0, 0, 0, 1, ((int*)(t13)));
    t3 = 1;
    goto LAB5;

LAB6:    t15 = (t0 + 11256);
    *((int *)t15) = 1;
    goto LAB8;

}

static void NetReassign_1358_11(char *t0)
{
    char t5[8];
    char *t1;
    char *t2;
    unsigned int t3;
    char *t4;
    char *t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;

LAB0:    t1 = (t0 + 10328U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    t3 = 0;
    t2 = (t0 + 3560U);
    t4 = *((char **)t2);
    memset(t5, 0, 8);
    t2 = (t5 + 4);
    t6 = (t4 + 4);
    t7 = *((unsigned int *)t4);
    t8 = (t7 >> 1);
    t9 = (t8 & 1);
    *((unsigned int *)t5) = t9;
    t10 = *((unsigned int *)t6);
    t11 = (t10 >> 1);
    t12 = (t11 & 1);
    *((unsigned int *)t2) = t12;
    t13 = (t0 + 13876);
    if (*((int *)t13) > 0)
        goto LAB4;

LAB5:    if (t3 > 0)
        goto LAB6;

LAB7:    t16 = (t0 + 11272);
    *((int *)t16) = 0;

LAB8:
LAB1:    return;
LAB4:    t14 = (t0 + 5400);
    xsi_vlogvar_assignassignvalue(t14, t5, 0, 0, 0, 1, ((int*)(t13)));
    t3 = 1;
    goto LAB5;

LAB6:    t15 = (t0 + 11272);
    *((int *)t15) = 1;
    goto LAB8;

}

static void NetReassign_1359_12(char *t0)
{
    char t5[8];
    char *t1;
    char *t2;
    unsigned int t3;
    char *t4;
    char *t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;

LAB0:    t1 = (t0 + 10576U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    t3 = 0;
    t2 = (t0 + 3560U);
    t4 = *((char **)t2);
    memset(t5, 0, 8);
    t2 = (t5 + 4);
    t6 = (t4 + 4);
    t7 = *((unsigned int *)t4);
    t8 = (t7 >> 2);
    t9 = (t8 & 1);
    *((unsigned int *)t5) = t9;
    t10 = *((unsigned int *)t6);
    t11 = (t10 >> 2);
    t12 = (t11 & 1);
    *((unsigned int *)t2) = t12;
    t13 = (t0 + 13880);
    if (*((int *)t13) > 0)
        goto LAB4;

LAB5:    if (t3 > 0)
        goto LAB6;

LAB7:    t16 = (t0 + 11288);
    *((int *)t16) = 0;

LAB8:
LAB1:    return;
LAB4:    t14 = (t0 + 5560);
    xsi_vlogvar_assignassignvalue(t14, t5, 0, 0, 0, 1, ((int*)(t13)));
    t3 = 1;
    goto LAB5;

LAB6:    t15 = (t0 + 11288);
    *((int *)t15) = 1;
    goto LAB8;

}

static void NetReassign_1360_13(char *t0)
{
    char t5[8];
    char *t1;
    char *t2;
    unsigned int t3;
    char *t4;
    char *t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;

LAB0:    t1 = (t0 + 10824U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    t3 = 0;
    t2 = (t0 + 3560U);
    t4 = *((char **)t2);
    memset(t5, 0, 8);
    t2 = (t5 + 4);
    t6 = (t4 + 4);
    t7 = *((unsigned int *)t4);
    t8 = (t7 >> 3);
    t9 = (t8 & 1);
    *((unsigned int *)t5) = t9;
    t10 = *((unsigned int *)t6);
    t11 = (t10 >> 3);
    t12 = (t11 & 1);
    *((unsigned int *)t2) = t12;
    t13 = (t0 + 13884);
    if (*((int *)t13) > 0)
        goto LAB4;

LAB5:    if (t3 > 0)
        goto LAB6;

LAB7:    t16 = (t0 + 11304);
    *((int *)t16) = 0;

LAB8:
LAB1:    return;
LAB4:    t14 = (t0 + 5720);
    xsi_vlogvar_assignassignvalue(t14, t5, 0, 0, 0, 1, ((int*)(t13)));
    t3 = 1;
    goto LAB5;

LAB6:    t15 = (t0 + 11304);
    *((int *)t15) = 1;
    goto LAB8;

}


extern void unisims_ver_m_00000000002959422570_2914997490_init()
{
	static char *pe[] = {(void *)Cont_1313_0,(void *)Cont_1314_1,(void *)Cont_1315_2,(void *)Cont_1333_3,(void *)NetDecl_1351_4,(void *)Always_1353_5,(void *)Always_1377_6,(void *)Always_1398_7,(void *)Always_1423_8,(void *)Always_1447_9,(void *)NetReassign_1357_10,(void *)NetReassign_1358_11,(void *)NetReassign_1359_12,(void *)NetReassign_1360_13};
	xsi_register_didat("unisims_ver_m_00000000002959422570_2914997490", "isim/isim_test.exe.sim/unisims_ver/m_00000000002959422570_2914997490.didat");
	xsi_register_executes(pe);
}

extern void unisims_ver_m_00000000002959422570_2749224905_init()
{
	static char *pe[] = {(void *)Cont_1313_0,(void *)Cont_1314_1,(void *)Cont_1315_2,(void *)Cont_1333_3,(void *)NetDecl_1351_4,(void *)Always_1353_5,(void *)Always_1377_6,(void *)Always_1398_7,(void *)Always_1423_8,(void *)Always_1447_9,(void *)NetReassign_1357_10,(void *)NetReassign_1358_11,(void *)NetReassign_1359_12,(void *)NetReassign_1360_13};
	xsi_register_didat("unisims_ver_m_00000000002959422570_2749224905", "isim/isim_test.exe.sim/unisims_ver/m_00000000002959422570_2749224905.didat");
	xsi_register_executes(pe);
}
